package day21programs;
//`File Serialization Program
import java.io.Serializable;
public class Student implements Serializable {
	    private int sno; 
	  	private String sname;
		private float average;
		public void StudentDetails() {
			System.out.println("Student No: "+ sno + " Student Name: "+ sname + " Average: "+ average);
		}
		public Student(int sno, String sname, float average) {
			super();
			this.sno = sno;
			this.sname = sname;
			this.average = average;
		}
		public int getSno() {
			return sno;
		}
		public void setSno(int sno) {
			this.sno = sno;
		}
		public String getSname() {
			return sname;
		}
		public void setSname(String sname) {
			this.sname = sname;
		}
		public float getAverage() {
			return average;
		}
		public void setAverage(float average) {
			this.average = average;
		}
		
		

	}


