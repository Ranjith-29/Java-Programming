package day21programs;

public class ForNameDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//we can give like  this or we can use catch and try block
	/*	Class classObj = Class.forName("java.lang.System");
		System.out.println("Name of the class: "+classObj.getName());
		System.out.println("Is it an Interface: "+classObj.isInterface());
		String strObj = new String("This is a String arg");
		System.out.println("Class name of strObj: "+strObj.getClass());
		System.out.println("Class name ofclassObj: "+classObj.getClass()); */
		try {
			Class classObj = Class.forName("java.lang.System");
			System.out.println("Name of the class: "+classObj.getName());
			System.out.println("Is it an Interface: "+classObj.isInterface());
			String strObj = new String("This is a String arg");
			System.out.println("Class name of strObj: "+strObj.getClass());
			System.out.println("Class name ofclassObj: "+classObj.getClass());
			
		}catch(Exception e) {
		      e.printStackTrace();
         }

	}
}
