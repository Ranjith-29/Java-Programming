package day14programs;
//UpperLowerCaseProgram
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class RegExCase {

	public static void main(String[] args) {
		Pattern pattern =  Pattern.compile("[A-Z]");
		Matcher matcher1 = pattern.matcher("we are in lower case WE ARE IN UPPER CASE We Are In Mixed Case");
		while(matcher1.find()) {
			System.out.println("UPPER CASE: "+ matcher1.group());
		}
		Pattern pattern2 =  Pattern.compile("[a-z]");
		Matcher matcher2 = pattern2.matcher("we are in lower case WE ARE IN UPPER CASE We Are In Mixed Case");
		while(matcher2.find()) {
			System.out.println("lower case: "+ matcher2.group());
		}
	}

}
