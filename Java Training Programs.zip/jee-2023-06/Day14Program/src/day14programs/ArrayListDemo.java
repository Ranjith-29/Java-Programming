package day14programs;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<String> arraylist = new ArrayList<String>();
		arraylist.add("Ranjith");
		arraylist.add("Hari");
		arraylist.add("Nanban");
		arraylist.add("Sam");
		arraylist.add("Max");
		System.out.println("Elements of teh ArrayList " + arraylist);
		System.out.println("Size of the ArrayList " + arraylist.size());
		arraylist.add(2,"Mona");
		System.out.println("Elements of the ArrayList " + arraylist);
		System.out.println("Size of the ArrayList " + arraylist.size());
		arraylist.remove(3);
		System.out.println("Elements of the ArrayList " + arraylist);
		System.out.println("Size of the ArrayList " + arraylist.size());
		arraylist.remove("Max");
		System.out.println("Elements of the ArrayList " + arraylist);
		System.out.println("Size of the ArrayList " + arraylist.size());
	}

}
