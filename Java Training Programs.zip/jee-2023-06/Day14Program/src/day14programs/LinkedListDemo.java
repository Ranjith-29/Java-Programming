package day14programs;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String> linkedlist = new LinkedList<String>();
		linkedlist.add("Mango");
		linkedlist.add("Orange");
		linkedlist.add("Apple");
		linkedlist.add("Grapes");
		linkedlist.add("Pears");
		System.out.println("LinkedList Elements: "+linkedlist);
		linkedlist.add("Strawberry");
		linkedlist.add("Melon");
		linkedlist.add("BlueBerry");
		System.out.println("LinkedList Elements: "+linkedlist);
		linkedlist.removeFirst();
		System.out.println("LinkedList Elements: "+linkedlist);
		linkedlist.removeLast();
		System.out.println("LinkedList Elements: "+linkedlist);
		String fruit = linkedlist.get(4);
		System.out.println(fruit);
		System.out.println(linkedlist.set(4,  fruit)+" is good for health");
		System.out.println("LinkedList Elements: "+ linkedlist);
	}

}
