package day4programs;

import java.util.Scanner;

public class ifelseProgram1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int side1,side2;
		int side3;
		System.out.println("enter the length of a side1");
		side1 = sc.nextInt();
		System.out.println("enter the length of a side2");
		side2 = sc.nextInt();
		System.out.println("enter the length of a side3");
		side3 = sc.nextInt();
		if(side1 == side2 && side1 == side2 && side2 == side3) System.out.println("Three Sides are Equal : Equilateral Traingle");// TODO Auto-generated method stub
		else if(side1 == side2 || side1==side3 || side2==side3) System.out.println("Two Sides are Equal : Isosceles Traingle");
		else {
			System.out.println("Three Sides are UnEqual : Scalene Traingle");
		}
		System.out.println("\nenter the length of a side1");
		side1 = sc.nextInt();
		System.out.println("enter the length of a side2");
		side2 = sc.nextInt();
		System.out.println("enter the length of a side3");
		side3 = sc.nextInt();
		if(side1 == side2 && side1 == side2 && side2 == side3) System.out.println("Three Sides are Equal : Equilateral Traingle");// TODO Auto-generated method stub
		else if(side1 == side2 || side1==side3 || side2==side3) System.out.println("Two Sides are Equal : Isosceles Traingle");
		else {
			System.out.println("Three Sides are UnEqual : Scalene Traingle");
		}
		System.out.println("\nenter the length of a side1");
		side1 = sc.nextInt();
		System.out.println("enter the length of a side2");
		side2 = sc.nextInt();
		System.out.println("enter the length of a side3");
		side3 = sc.nextInt();
		if(side1 == side2 && side1 == side2 && side2 == side3) System.out.println("Three Sides are Equal : Equilateral Traingle");// TODO Auto-generated method stub
		else if(side1 == side2 || side1==side3 || side2==side3) System.out.println("Two Sides are Equal : Isosceles Traingle");
		else {
			System.out.println("Three Sides are UnEqual : Scalene Traingle");
		}
	}
	
	

}
