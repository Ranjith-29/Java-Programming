package day4programs;

public class CharEx1 {

	public static void main(String[] args) {
		char ch1,ch2;
		ch1 = 'X';
		ch2 = 89;
		System.out.println(" ch1: " + ch1);
		System.out.println(" ch2: " + ch1);
		ch2++;
		System.out.println(" ch2: " + ch2);
		// TODO Auto-generated method stub

	}

}
