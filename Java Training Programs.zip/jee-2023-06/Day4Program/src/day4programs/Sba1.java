package day4programs;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Sba1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int days = 1;
		String ANSI_YELLOW = "\u001B[33m";
		String ANSI_GREEN = "\u001B[42m";
		String ANSI_PURPLE = "\u001B[45m";
		String ANSI_CYAN = "\u001B[46m";
		String ANSI_COL = "\u001B[41m";
		String ANSI_RESET = "\u001B[0m";
	    String weekday;
	 //try	{
	    	do {
	    		try {
	    			System.out.println("Enter the Week Day");
					weekday = sc.next(); 
					switch(weekday)
					{
					case "Monday" :  
						
						if(weekday.equals("Monday")) 
							System.out.println(ANSI_GREEN+ "day " +days+"\t" + "have a  session "+weekday +ANSI_RESET );
						    System.out.println("===========================================");
						    days++;
							break;  
					case "Tuesday" :
						if(weekday.equals("Tuesday"))
							System.out.println(ANSI_PURPLE+ "day " +days+"\t" + "have a  session "+weekday +ANSI_RESET);
						    System.out.println("===========================================");
						    days++;
				            break;
					case "Wednesday" :
						if(weekday.equals("Wednesday")) 
							System.out.println(ANSI_CYAN+ "day " +days+"\t" + "have a  session "+weekday +ANSI_RESET);	
						    System.out.println("===========================================");
					        days++;
			                break;
							
					case "Thursday" :
						if (weekday.equals("Thursday"))
							System.out.println( "Public Holiday "+weekday );
						    System.out.println("===========================================");
						    days++;
						    break;
					case "Friday" :
						if (weekday.equals("Friday"))
			                System.out.println(ANSI_COL+ "day "+(days-1) + " have a session " +weekday +ANSI_RESET);
						    System.out.println("===========================================");
			            	days++;
			            	break;
					case "Saturday" :
						if (weekday.equals("Saturday")) 
					        System.out.println("day " +days+"\t" + "Week End "+weekday);
						    System.out.println("===========================================");
			            	days++;
			            	break;
					case "Sunday" :
						if(weekday.equals("Sunday"))
							System.out.println("day " +days+"\t" + "Week End "+weekday);
						    days++;
		            	    System.err.println("========================");	
		            	    break;
		            	    
			        default :
			        	   throw new InputMismatchException();
				} 
				
	      }catch (InputMismatchException ae) {
	  		System.err.println("Invalid Statement"+"/Enter the valid Day"+"Type Starting Letter of the day in Upper Case "+ae) ;
	  		days++;
			
	  	       }
	    }
	    while(days<=7); 
	    	 System.err.println("Session Day: "+(days-3));
	    	 System.err.println("Holiday/No Session: "+(days-4));
	    	 System.out.println(ANSI_YELLOW + "The Program Executed Successfully" +ANSI_RESET);
	
  }
}
			
			
		