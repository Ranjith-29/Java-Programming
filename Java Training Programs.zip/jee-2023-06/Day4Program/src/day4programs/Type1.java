package day4programs;

public class Type1 {

	public static void main(String[] args) {
		int num1_int = 10;
		long num2_long;
		float num3_float;
		

	}

}
