package day4programs;

import java.util.Scanner;

public class ControlFlow1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int days = 1;
		String weekday;
		while(days <= 7) {
			System.out.println("Enter the Week Day");
			weekday = sc.next();
	          if(weekday.equals("Monday") || weekday.equals("monday") ||  weekday.equals("Tuesday") ||weekday.equals("tuesday") || weekday.equals("Wednesday") || weekday.equals("wednesday") ) {
				System.out.println("day " +days+"\t" + "have a  session "+weekday);			
              // days++;
		}
			else if (weekday.equals("Thursday")|| weekday.equals("thursday"))
				{
				System.out.println( "Public Holiday "+weekday );
				 days++;
				}
            else if (weekday.equals("Saturday") || weekday.equals("saturday")||weekday.equals("Sunday") || weekday.equals("sunday"))
			{
            	System.out.println("day " +days+"\t" + "Week End "+weekday);	
            	days++;
            }
            else if (weekday.equals("Friday")|| weekday.equals("friday"))
            {
            	System.out.println("Day 4 have a session " +weekday);
            	 days++;
            }
            else {
            	System.err.println("Invalid Day Name"+"\nEnter the Correct Weekday");
          	    days++;
            	  //System.err.println the word err is used to differntiate the 
            	  // wrong part with color
            }   
		}
			 
	

	}

}
