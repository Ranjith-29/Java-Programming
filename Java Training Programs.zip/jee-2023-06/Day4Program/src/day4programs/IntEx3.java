package day4programs;

import java.util.Scanner;

public class IntEx3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int a;
        double s;
        float b;
		System.out.println("Enter the length of side of Square");
		a = sc.nextInt();
		System.out.println("Enter the length of side of Square");
		s = sc.nextDouble();
		System.out.println("Enter the length of side of Square");
		b = sc.nextFloat();
		System.out.println("Int type of Area of a Square: " +a*a);
		System.out.println("Double type of Area of a Square: " +s*s);
		System.out.println("Float type of Area of a Square: " +b*b);
		// TODO Auto-generated method stub

	}

}
