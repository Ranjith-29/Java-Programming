package daytwo;

import java.util.Scanner;

public class IntEx5 {

	public static void main(String[] args) {
        //this is a comment which is ignored by the compiler
		/*
		 this is a 
		 multi line 
		 comment
		 */
		Scanner scanner = new Scanner(System.in); //To get user input thereby making the application dynamic
		float height; //float height = 5.2f; hard coded
		int year; //declaring identifier year of int type
		System.out.println("Enter Your Name: "); //printing a prompt for user input for name
		String name = scanner.nextLine(); //declaring and initializing name of string type
		System.out.println("Enter your height: "); //printing a prompt for user input for height
		height = scanner.nextFloat(); //taking user input for height
		System.out.println("Enter the year: "); //printing a prompt for user input for year
		year= scanner.nextInt();
		System.out.println("Name: "+name); //printing a meaninful output
		System.out.println("Year : My Height");
		System.out.println("........."); //Line separation
		System.out.println(year+ " : " +height); //using + is a concatenation operator

	}

}
