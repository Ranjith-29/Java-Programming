package daytwo;

public class IntEx3 {

	public static void main(String[] args) {
		float height = 6.1f;
		int year = 2020;
		System.out.println("Year : My Height");
		System.out.println(".........");
		System.out.println(year+ " : " +height);

	}

}
