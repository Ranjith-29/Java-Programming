package milkshakeprojects;
import java.util.Scanner;
import java.util.ArrayList;
public class WorldOfWonders {
	Scanner sc = new Scanner(System.in);
	int price=0;
	ArrayList<String> array = new ArrayList<String>();
	Scanner scan = new Scanner(System.in);
	public void BelgiumExplode() {
		price = price + 250;
		System.out.println("\n BelgiumExplode Milkshake Added to Cart");
		array.add(" BelgiumExplode");
	}
	public void IndianIceCream() {
		price = price + 250;
		System.out.println("\nIndianIceCream Milkshake Added to Cart");
		array.add("IndianIceCream");
	}
	public void AwesomeAustralia() {
		price = price + 250;
		System.out.println("\nAwesomeAustralia Milkshake Added to Cart");
		array.add("AwesomeAustralia");
	}
	public void BangBangBangkok() {
		price = price + 250;
		System.out.println("\nBangBangBangkok Milkshake Added to Cart");
		array.add("BangBangBangkok");
	}
	public void PrettyParis() {
		price = price + 250;
		System.out.println("\nPrettyParis Milkshake Added to Cart");
		array.add("PrettyParis");
	}
	public void WorldOfWondersMenu() {
		int LoopVariable=0;
		while(LoopVariable==0){
			char choice;
			System.out.println(" ____________________________________|");
			System.out.println("|                                    |");
			System.out.println("|WorldOfWonders Milkshakes      ₹250 |");
			System.out.println("| ___________________________________|");
			System.out.println("|                                    |");
			System.out.println("|1.BelgiumExplode                    |"); 
			System.out.println("|2.IndianIceCream                    |");
			System.out.println("|3.AwesomeAustralia                  |");
			System.out.println("|4.BangBangBangkok                   |");
			System.out.println("|5.PrettyParis                       |");
			System.out.println("|6.Exit                              |");
			System.out.println("|____________________________________|");
			try {
				System.out.print("\n\nEnter your choice to add item to Cart : ");
				choice = scan.next().charAt(0);
				if(choice == '1' || choice == '2' || choice == '3' || choice == '4' || choice == '5' || choice == '6') {
						switch(choice) {
						case '1': BelgiumExplode();break;
						case '2': IndianIceCream();break;
						case '3': AwesomeAustralia();break;
						case '4': BangBangBangkok();break;
						case '5': PrettyParis();break;
						case '6': LoopVariable=1;
						
						}
				}
				else
					throw new Exception("Entered input doesn't Match with the Options provided.");
			}catch (Exception e) {
		        System.out.println("\nError : " + e.getMessage());
		        System.out.println("\nPlease check the Input you have entered.");
		      } 
		}
	}
}
/*	int quantity;
	int price = 250;
	int total = 0;
	void Welcome() {
		System.out.println("Welcome to shop");
	}
    void display() {
    	System.out.println("Wolder Of Wonders");
    	System.out.println("Wolder Of Wonders:  250/-");
    	System.out.println("------------------------");
    	System.out.println(" 1. BelgiumExplode "+"\n 2. IndianIceCream "+"\n 3. AwesomeAustralia "+"\n 4. BangBangBangKok "+"\n 3. PrettyParis ");
    	System.out.println();
    	
    }
	void BelgiumExplode(){
		System.out.println("You have Added Belgium Explode");
		System.out.println();
		System.out.println("Enter the Desired Quantity");
		quantity = sc.nextInt();
	    total = total + quantity + price;
	}
	void IndianIceCream(){
		System.out.println("You have Added IndianIceCream");
		System.out.println();
		System.out.println("Enter the Desired Quantity");
		quantity = sc.nextInt();
	    total = total + quantity + price;
	}
	void AwesomeAustralia(){
		System.out.println("You have Added AwesomeAustralia");
		System.out.println();
		System.out.println("Enter the Desired Quantity");
		quantity = sc.nextInt();
	    total = total + quantity + price;
	}
	void BangBangBangkok(){
		System.out.println("You have Added BangBangBangkok");
		System.out.println();
		System.out.println("Enter the Desired Quantity");
		quantity = sc.nextInt();
	    total = total + quantity + price;
	}
	void PrettyParis(){
		System.out.println("You have Added PrettyParis");
		System.out.println();
		System.out.println("Enter the Desired Quantity");
		quantity = sc.nextInt();
	    total = total + quantity + price;
	}

} */
