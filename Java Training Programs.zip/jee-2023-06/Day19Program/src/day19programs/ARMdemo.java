package day19programs;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileInputStream;
public class ARMdemo {

	public static void main(String[] args) throws FileNotFoundException , IOException {
		int  ctr;
		try(FileInputStream fin = new FileInputStream("File1.txt")){
			do {
				ctr = fin.read();
				if(ctr !=-1) 
					System.out.print((char)ctr);
			}while(ctr !=1);
		}catch(FileNotFoundException fnfe) {
			 System.out.println(fnfe);
		}
	}
}
			


