/**
 * 
 */
/**
 * @author dxcjavafsd29
 *
 */
module Day24Program {
	requires java.sql;
}