package day3programs;

import java.util.Scanner;

public class IntEx11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double bc,wf;
		double choco,rv;
		int q1,q2,q3,q4;
		System.out.println("Enter the Prices of Black Current");
		bc = sc.nextDouble();
		System.out.println("Enter the Prices of White Forest");
		wf = sc.nextDouble();
		System.out.println("Enter the Prices of Choco");
		choco = sc.nextDouble();
		System.out.println("Enter the Prices of rv");
		rv = sc.nextDouble();
		System.out.println("Enter the Qty of Black Current");
		q1 = sc.nextInt();
		System.out.println("Enter the Qty of White Forest");
		q2 = sc.nextInt();
		System.out.println("Enter the Qty of Choco");
		q3 = sc.nextInt();
		System.out.println("Enter the Qty of rv");
		q4 = sc.nextInt();
		System.out.println("---------------------------------------------------");
		System.out.println("---------------------------------------------------");
		System.out.println("Menu Item          Price      Qty           Payable");
		System.out.println("---------------------------------------------------");
		System.out.println("Black current     "+bc+"         "+q1+"           "+bc*q1);
		System.out.println("white forrest     "+wf+"         "+q2+"           "+wf*q2);
		System.out.println("Chocolate         "+choco+"         "+q3+"           "+choco*q3);
		System.out.println("Red valvet        "+rv+"         "+q1+"           "+rv*q4);
		System.out.println("-------------------------------------------------------");
		System.out.println("-------------------------------------------------------");
		double Total = ( (bc*q1)+(wf*q2)+(choco*q3)+(rv*q4)); 
		System.out.println("Total                                        "     +Total);
		System.out.println("===========================================================");
	}
	

}
