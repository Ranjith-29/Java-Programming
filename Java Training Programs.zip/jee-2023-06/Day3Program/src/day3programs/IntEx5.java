package day3programs;

import java.util.Scanner;

public class IntEx5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int benz;
		int duster;
		int ferrari;
		int total;
		System.out.println("Enter the number of Benz");
		benz = sc.nextInt();
		System.out.println("Enter the number of Duster");
		duster = sc.nextInt();
		System.out.println("Enter the number of Ferrari");
		ferrari = sc.nextInt();
	    total = benz + duster+ferrari;
		System.out.println("The sum of three cars is: "+total);// TODO Auto-generated method stub

	}

}
