package day3programs;

import java.util.Scanner;

public class IntEx7 {

	public static void main(String[] args) {
		double height,weight;
		int age;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Name");
		String name = sc.nextLine();
		System.out.println("Enter the height");
		height = sc.nextDouble();
		System.out.println("Enter the weight");
		weight = sc.nextDouble(); 
		System.out.println("Enter the age");
		age = sc.nextInt(); 
		System.out.println("Enter the Marital Status");
		String mname = sc.next();
		System.out.println("Printing all details :\n"+name+" "+height+" "+weight+" "+age+" "+mname);
		// TODO Auto-generated method stub

	}

}
