package day3programs;


public class IntEx1 {

	public static void main(String[] args) {
		float deposit = 1000000;	
		int year=2023;
		System.out.println("Deposit: "+deposit);
		System.out.println("if she keeps for 6.5 years, she will get doubt");
		year+=6.5;
		deposit=deposit*2;
		System.out.println("At" + year +"th year she will get : "+deposit);
		System.out.println("if she keeps for 20 years");
		year+=20;
		deposit=deposit*4;
		System.out.println("At" + year +"th year she will get : "+deposit);
				
		// TODO Auto-generated method stub

	}

}
