package day3programs;

import java.util.Scanner;

public class IntEx10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		double tempc;
		double tempf;
		System.out.println("Enter the temperature in Celsius");// TODO Auto-generated method stub
        tempc = sc.nextDouble(); 
        tempf = (tempc*9/5)+32;
        System.out.println("Temperature in fahrenheit : "+tempf);
	}

}
