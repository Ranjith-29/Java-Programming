package day5programs;

import java.util.Scanner;

public class ArrayProgram3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String standard;
		double total = 0, avg;
		double subjectmarks[];
		subjectmarks = new double[6];
		System.out.println("Enter the name");
		String studentname = sc.nextLine();
		System.out.println("Enter the Rollno");
		int rollno = sc.nextInt();
		System.out.println("Enter the Class");
		standard = sc.next();
		System.out.println("Enter the Tamil Marks");
		subjectmarks[0] = sc.nextDouble();
		System.out.println("Enter the English Marks");
		subjectmarks[1] = sc.nextDouble();
		System.out.println("Enter the Maths Marks");
		subjectmarks[2] = sc.nextDouble();
		System.out.println("Enter the Science Marks");
		subjectmarks[3] = sc.nextDouble();
		System.out.println("Enter the Social Science Marks");
		subjectmarks[4] = sc.nextDouble();
		System.out.println("Enter the Computer Science Marks");
		subjectmarks[5] = sc.nextDouble();
		for (int i = 0; i < 6; i++) {
			total = total + subjectmarks[i];
		}
		System.out.println("========================================");
		System.out.println("        Dxc School Report                ");
		System.out.println("========================================");
		System.out.println("Name: " + studentname + "\t " + "Class: " + standard);
		System.out.println("========================================");
		System.out.println("Tamil: " + "\t         " + subjectmarks[0]);
		System.out.println("========================================");
		System.out.println("English: " + "\t " + subjectmarks[1]);
		System.out.println("========================================");
		System.out.println("Maths: " + "\t         " + subjectmarks[2]);
		System.out.println("========================================");
		System.out.println("Science: " + "\t " + subjectmarks[3]);
		System.out.println("========================================");
		System.out.println("Social: " + "\t " + subjectmarks[4]);
		System.out.println("========================================");
		System.out.println("ComputerScience: "+subjectmarks[5]);
		System.out.println("========================================");
		// double totalmarks =
		// (subjectmarks[0]+subjectmarks[1]+subjectmarks[2]+subjectmarks[3]+subjectmarks[4]+subjectmarks[5]);
		System.out.println("Total: " + "\t         " + total);
		System.out.println("========================================");
		avg = total / 6;
		System.out.println("Average: " + "\t " + avg + "%");
		System.out.println("========================================");
		if (avg >= 90 && avg <= 100) {
			System.out.println("Grade:" + "\t          " +   "A+");
		} else if (avg >= 80 && avg <= 89) {
			System.out.println("Grade: " + "\t         " +   "A");
		} else if (avg >= 70 && avg <= 79) {
			System.out.println("Grade: " + "\t         " +   "B+");
		} else if (avg >= 60 && avg <= 69) {
			System.out.println("Grade: " + "\t         " +   "B");
		} else if (avg >= 60 && avg <= 69) {
			System.out.println("Grade: " + "\t         " +   "C+");
		} else if (avg >= 50 && avg <= 59) { 
			System.out.println("Grade: " + "\t         " +   "C");
		} else if (avg >= 40 && avg <= 49) {
			System.out.println("Grade: " + "\t         " +   "D");
		} else { 
			System.out.println("Grade: " + "\t         " +   "E");
		}
	}

}
