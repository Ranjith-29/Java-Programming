package day20programs;
//Alive Join Program
public class NewThread2  implements Runnable {
	Thread thread;
	String name;
	NewThread2(String threadName){//constructor
	name = threadName;
	thread = new Thread(this, "Child - Thread");
	System.out.println("Child thread : " +thread);
	thread.start();
	}
	public void run() {
	try {
	for(int ctr = 5; ctr>0; ctr--) {
	System.out.println( name + " : " +ctr);
	Thread.sleep(2000);
	  }
	
	}catch(InterruptedException e) {
	      e.printStackTrace();
	} System.out.println( name + " Exiting ");
	
  }

}



