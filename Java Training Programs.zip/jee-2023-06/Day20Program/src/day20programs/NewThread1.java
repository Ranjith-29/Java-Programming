package day20programs;
//Multi thread
public class NewThread1 implements Runnable {
	Thread thread;
	String name;
	NewThread1(String threadName){//constructor
	name = threadName;
	thread = new Thread(this, "Child - Thread");
	System.out.println("Child thread : " +thread);
	thread.start();
	}
	public void run() {
	try {
	for(int ctr = 5; ctr>0; ctr--) {
	System.out.println("Child Thread : " + name + " : " +ctr);
	Thread.sleep(2000);
	  }
	
	}catch(InterruptedException e) {
	      e.printStackTrace();
	} System.out.println("Exiting child thread");
	
  }

}
