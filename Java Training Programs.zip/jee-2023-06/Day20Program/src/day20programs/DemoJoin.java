package day20programs;
//Alive Join Program
public class DemoJoin {

	public static void main(String[] args) {
		NewThread2 obj1 = new NewThread2("Thread-One");
		NewThread2 obj2 = new NewThread2("Thread-Two");
		NewThread2 obj3 = new NewThread2("Thread-Thee");
		System.out.println("Is Thread-One Alive: " + obj1.thread.isAlive());
		System.out.println("Is Thread-Two Alive: " + obj2.thread.isAlive());
		System.out.println("Is Thread-Three Alive: " + obj3.thread.isAlive());
		try {
			obj1.thread.join();
			obj2.thread.join();
			obj3.thread.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Is Thread-One Alive: " + obj1.thread.isAlive());
		System.out.println("Is Thread-Two Alive: " + obj2.thread.isAlive());
		System.out.println("Is Thread-Three Alive: " + obj3.thread.isAlive());
		System.out.println("Main Thread Exits");
		
		// TODO Auto-generated method stub

	}

}
