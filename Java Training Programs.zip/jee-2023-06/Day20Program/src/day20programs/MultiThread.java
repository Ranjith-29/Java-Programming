package day20programs;

public class MultiThread{

	public static void main(String[] args) {
				new NewThread1("Thread-One");
				new NewThread1("Thread-Two");
				new NewThread1("Thread-Three");
				try {
					Thread.sleep(30000);
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Main thread Exiting");

	}

}
