package day20programs;
class Callme{
	void call(String msg) {
		System.out.println("[ " + msg);
		try {
			Thread.sleep(3000);
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(" ]");
	}
}
class Caller implements Runnable{
	String msg;
	Callme callMe;
	Thread thread;
	public Caller(Callme callMe, String str) {
		this.callMe = callMe;
		msg = str;
		thread = new Thread(this);
		thread.start();
	}
	public void run() {
		synchronized(callMe) {
			callMe.call(msg);
		}
	}

}
public class Sync1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Callme callMe = new Callme();
		Caller obj1 = new Caller(callMe, "Hello from first Object");
		Caller obj2 = new Caller(callMe, "This part is also Synchronized");
		Caller obj3 = new Caller(callMe, "Final Part of Synchronization");
		try {
			obj1.thread.join();
			obj2.thread.join();
			obj3.thread.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
