package day9programs;
/* final class A {
	  void meth() {
		 System.out.println("This is a final method.");
	 }
}
 class B extends A { // can't override its show is error coz we use  key word final and static when we remove the key word it works
	     static void meth() {
		 // can't override its show is error coz we use  key word final and static when we remove the key word it works
		 System.out.println("illegeal.");
	 }
} */
class A {
	  void meth() {
		 System.out.println("This is a final method.");
	 }
 }
 class B extends A {
	     void meth() {
		 // here can override its doesn't show is error coz we removed  key word final and static when we remove the key word it works
		 System.out.println("illegeal.");
	 }
}