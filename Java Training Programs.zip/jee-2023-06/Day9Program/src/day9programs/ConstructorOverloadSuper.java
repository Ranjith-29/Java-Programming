package day9programs;
//CONSTRUCTOR OVERLOADING
public class ConstructorOverloadSuper {
	int num1,num2;
	ConstructorOverloadSuper(){
		num1 = 10;         //initializing value in constructor
		num2 = 20;
	}
	ConstructorOverloadSuper(int num1, int num2) {
		this.num1 = num1;     //GETTING VALUE
		this.num2 = num2;
	}
    void calculate() {
    	System.out.println("Sum is " + (num1 + num2));  
    }
    void calculate(String str) {
    	System.out.println(str  + (num1 * num2));
    }
}
