package day9programs;
//MultipleInterface
public interface Iface1 {
	int gold = 20000000;
    int diamond = 30000000;
}
