package day9programs;

public class MyInterfaceMain {

	    public static void main(String[] args) {
		MYSQL mysql = new MYSQL();
		OracleDb oracledb = new OracleDb();
		mysql.connect();
		oracledb.connect();

	}

}
