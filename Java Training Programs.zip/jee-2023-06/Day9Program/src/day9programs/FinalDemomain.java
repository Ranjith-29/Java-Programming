package day9programs;

public class FinalDemomain {

	public static void main(String[] args) {
				B obj = new B();
				obj.meth();
	}
}


