package day9programs;

public class IfaceClass implements Iface1, Iface2 {
	void goldCumulative() {
		System.out.println("Gold: "+(gold+gold1));
	}
	void diamondCumulative() {
		System.out.println("Diamond: "+(diamond+diamond1));
	}

}
