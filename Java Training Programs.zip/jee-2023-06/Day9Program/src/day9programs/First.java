package day9programs;
//multi level Interface
public interface First {
	void display1();

}
