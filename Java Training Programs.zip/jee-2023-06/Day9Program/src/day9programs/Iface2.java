package day9programs;

public interface Iface2 {
	int gold1 = 90000000;
    int diamond1 = 80000000;
}


