package day9programs;

public class InterfaceMultilevelMain {

	public static void main(String[] args) {
		InterfaceMultiLevel iml = new InterfaceMultiLevel();
        iml.display1();
        iml.display2();
        iml.display3();
	}

}
