package day9programs;
//multi level Interface
public interface Second extends First {
     void display2();
}
