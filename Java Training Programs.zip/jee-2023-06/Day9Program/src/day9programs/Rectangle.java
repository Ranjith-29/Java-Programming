package day9programs;

public  class Rectangle extends GeometricFigure {
  public Rectangle(double dim1, double dim2) {
	  super(dim1,dim2);
  }
  double area() {
	  return dim1 * dim2;
  }
}
