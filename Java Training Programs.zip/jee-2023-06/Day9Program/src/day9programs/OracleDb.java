package day9programs;

public class OracleDb implements MyInterface {

	@Override //Anotation
	public void connect() {
		System.out.println("Connecting to OracleDB DB");

	}

}
