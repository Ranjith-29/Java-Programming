package day9programs;

public class ConstructorOverloadmain {

	public static void main(String[] args) {
	/*	ConstructorOverloadSub sub = new ConstructorOverloadSub();
		ConstructorOverloadSub sub1 = new ConstructorOverloadSub(5,10); */
		
		ConstructorOverloadSub sub = new ConstructorOverloadSub(30); // overriding 
		ConstructorOverloadSub sub1 = new ConstructorOverloadSub(5,10,15);
		
	/*	sub.calculate();
		sub.calculate("product is "); */
		sub.calculate();
		sub.calculate("Super String arg: ");
		
		System.out.println("=========================");
	/*	sub1.calculate();
		sub1.calculate("product is "); 

	} */
	    sub.calculate();
	    sub.calculate("Super String arg: ");

    }
}
