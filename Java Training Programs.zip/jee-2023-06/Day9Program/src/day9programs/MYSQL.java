package day9programs;

public class MYSQL implements MyInterface {

	@Override
	public void connect() {
		System.out.println("Connecting to MySQL DB");
		// TODO Auto-generated method stub

	}

}
