package day15programs;
import java.util.ArrayDeque; //ArrayStack
public class ArrayDequeDemo {

	public static void main(String[] args) {
		ArrayDeque<String> adq = new ArrayDeque<String>();
		adq.push("Jasmine");
		adq.push("Rose");
		adq.push("Lilly");
		adq.push("Tulip");
		System.out.println("Array Deque: "+ adq);
		while(adq.peek()!=null)
		{
		  System.out.println("POP: "+ adq.pop() + " ");	
		}
		
	}

}
