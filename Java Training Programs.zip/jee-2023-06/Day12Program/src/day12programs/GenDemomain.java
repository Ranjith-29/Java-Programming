package day12programs;

public class GenDemomain {

	public static void main(String[] args) {
		GenDemo<Double> intob = new GenDemo<Double>(299.9);
		intob.showType();
		double value = intob.getobj();
		System.out.println("Value returned " + value);
		GenDemo<String> strob = new GenDemo<String>("Ranjith");
		strob.showType();
		String str = strob.getobj();
		System.out.println("Your Name is " +str);
		// TODO Auto-generated method stub

	}

}
