package cabsba3;
import java.util.Scanner;
import java.util.ArrayList;
public class Carmain {

	public static void main(String[] args) {
	/*	String ANSI_CYAN = "\u001B[36m";
		String ANSI_GREEN = "\u001B[32m";
		String ANSI_BLUE = "\u001B[44m";
		String ANSI_RED = "\u001B[41m";
		String ANSI_WHITE = "\u001B[37m";
		String ANSI_RESET = "\u001B[0m";
		StringBuilder stringbuilder = new StringBuilder(ANSI_CYAN+"REGISTER"+ANSI_RESET);
		StringBuilder stringbuilder1 = new StringBuilder(ANSI_RED+"-------------ENTER LOGIN CREDENTIALS--------------"+ANSI_RESET);
		Userlogin obj = new Userlogin();
		String str[] = {"Name","Username","Password","Email id","Mobile No","Gender"};
		String str1[] = new String[5];
		Scanner sc = new Scanner(System.in);
		System.out.println("|==========================|");
		System.out.println(ANSI_BLUE+ANSI_WHITE+"|-WELCOME TO MOKKA TRAVELS-|"+ANSI_RESET);
		System.out.println("|==========================|");
		System.out.println(stringbuilder);
		for(int i=0;i<=4;i++) {
			System.out.println("Enter "+str[i]+"  :  ");
			str1[i]=sc.nextLine();
			
		}
		System.out.println(ANSI_GREEN+"\nSuccessfully Registered..!"+ANSI_RESET);
	    System.out.println("===================================="); */
	   // System.out.println(ANSI_WHITE+stringbuilder1+ANSI_RESET);
	    Userlogin obj = new Userlogin();
	    obj.LoginInput();
	    obj.LoginPass();
	    obj.JourneyMessage();
	    obj.Location();
	    obj.Chooseplace();
	    obj.bookCab();
	    obj.tipChoice();
	    obj.changeLocation();
	    obj.userCancel();
	    obj.Payment();
	    
	    }
	    
	    
	}


