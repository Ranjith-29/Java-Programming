package cabsba3;
import java.util.Scanner;
import java.util.ArrayList;
public abstract class Userpayment extends Userlogin {
	/* Userpayment(String userid, String name, String pass, String gender, String userid2, String pass2) {
		super(userid, name, pass, gender);
		userid = userid2;
		pass = pass2;
	} */
	 Scanner sc = new Scanner(System.in);
void Payment() {	 
	Scanner sc = new Scanner(System.in);
	System.out.println("Here you go,Payment methods/Options");
	int pay = sc.nextInt();
	System.out.println("1.cash\n 2.phonepay\n 3.GooglePay\n 4.paytm");
	int Option =sc.nextInt();
	try {
		switch(Option) {
		case 1 :
			System.out.println("paid by cash ");
			break;
		case 2 :
			System.out.println("Amount transferred through  phonepay");
			break;
		case 3 :
			System.out.println("Amount transferred through gpay");
			break;
		case 4 :
			System.out.println("Amount transferred through paytm");
			break;
			default : throw new Exception();
				
		   }
	}catch(Exception ae) {
		System.out.println("Invalid details, try again"+ae);
	}
	
   }
   void Location() {
	   String locate;
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Mark your Current Location..!:(MARKED or NO)");
	   locate = sc.nextLine().toUpperCase();
	   if(locate.equals("MARKED")) {
		   System.out.println("Successfully, Your Current Location Marked");
		   System.out.print("\n");
		   System.out.print("Are you like to click destination..!");
	   }else {
		   System.out.println("Mark Your Location");
		   Location();		   
	   
	   }   
		   
   }
   int baseFare = 10;
   int rate,totalFare=0;
   void Chooseplace() {
	   ArrayList<String> list = new ArrayList<String>();
	   list.add("1.Trichy Central Bus Stand");
	   list.add("2.Trichy Chathiram Bus Stand");
	   list.add("3.Trichy Thillai Nagar");
	   list.add("4.Trichy Thennur");
	   list.add("5.Trichy Srirangam");
	  /* list.add("6.Trichy Malaikottai");
	   list.add("7.Trichy Samayapuram Temple");
	   list.add("8.Trichy Railway Station");
	   list.add("9.Trichy Puthur 4 Road");
	   list.add("10.Trichy Airport");
	   list.add("11.Trichy Uraiyur"); */
	   
	   System.out.println("List of places");
	   System.out.println(list);
	   System.out.println("\n");
	  
	   System.out.println("Select the source location");
	   System.out.println("printLocations :"+list);
	   String source=sc.nextLine();
	   System.out.println("select the destination location");
	   System.out.println("printLocations : "+list);
	   String destination=sc.nextLine();
	   if(source.equals("Trichy Central Bus Stand") && destination.equals("Trichy Chathiram Bus Stand") || source.equals("Trichy Chathiram Bus Stand") && destination.equals("Trichy Central Bus Standd")) {
		    int rate = 50;
			int totalFare = rate+rate;
		}else if(source.equals("Trichy Chathiram Bus Stand") && destination.equals("Trichy Thillai Nagar") || source.equals("Trichy Thillai Nagar") && destination.equals("Trichy Chathiram Bus Stand") ) {
			rate = 21;
			totalFare +=rate;
		}else if(source.equals("Trichy Thillai Nagar") && destination.equals("Trichy Thennur") || source.equals("Trichy Thennur") && destination.equals("Trichy Thillai Nagar") ) {
			rate = 35;
			totalFare +=rate;
		}else if(source.equals("Trichy Thennur") && destination.equals("Trichy Srirangam") || source.equals("Trichy Srirangam") && destination.equals("Trichy Thennur" )) {
			rate = 50;
			totalFare +=rate;
		}else {
			System.out.println("Sorry:( we currently  do not provide cab sevice from " + source + " to " + destination + " is $" + rate);
		}	
		System.out.println("Are you wishing to cancel the ride(yes/no)");
		String decide = sc.nextLine();
		if (decide.equals("yes")) {
			userCancel();
		}
	    
		System.out.println("Do you want to fix the location(Yes/no)");
		String select = sc.nextLine().toLowerCase();
		if(select.equals("yes")) {
		
	//	CabDriver myCab = new CabDriver(" john Doe" , "AB1234","Innova");
		
	//	System.out.println("The fare for your journey from " + source + " to " + destination + " and baseFare is "+ baseFare+ "  total to pay is $" + rate);
	   }
	   
   }
 
}
	
		
	
	
	
				
		
		
		
	
		










	

