package day8programs;

public class OverrideMain {

	public static void main(String[] args) {
		OverrideChild orc = new OverrideChild();// TODO Auto-generated method stub
        orc.OverrideMethod();
	}

}
