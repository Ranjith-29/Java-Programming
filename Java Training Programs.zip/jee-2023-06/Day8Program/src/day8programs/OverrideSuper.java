package day8programs;

public class OverrideSuper {
         void OverrideMethod( ) {
        	 System.out.println("The Parent Class Method");
         }
}
