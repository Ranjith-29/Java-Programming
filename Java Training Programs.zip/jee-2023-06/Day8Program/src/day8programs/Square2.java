package day8programs;

public class Square2 extends Square {
	 Square2(){
		  super(); 
	  } 
	/*Super Keyword is only used when you extend the class with superclass
	  if not can't use this Super Keyword there*/
	/* Square2(float side) {
		this.side = side;
	  } */
       void square2Fn() {
	   System.out.println("I am from Square2");
		
	}

}
