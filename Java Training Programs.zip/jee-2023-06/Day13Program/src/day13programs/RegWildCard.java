package day13programs;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
///finding starting letter and ending letter example funny family furry,fancy is called wildcard//
public class RegWildCard {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("f.+y");
		Matcher matcher1 = pattern.matcher("my family is always funny is fancy like a fairyvery frequently");
		/* its catch f in starting and see where the end of sentence has y if its 
		 * there print match found else print match not found
		*/
		while(matcher1.find()) {
	        	System.out.println("Match Found: "+ matcher1.group());
		}
	}
		

}
