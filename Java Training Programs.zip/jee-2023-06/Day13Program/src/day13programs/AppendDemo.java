package day13programs;

public class AppendDemo {

	public static void main(String[] args) {
		String string1;
		int num1 = 2023;
		StringBuffer stringbuffer = new StringBuffer("Original Value");
		System.out.println(stringbuffer);
	    string1 = stringbuffer.append(" num1 = ").append(num1).append(" !!!").toString(); //tostring is used for converting stringbuffer to string
		System.out.println(string1);
		stringbuffer.append(" Value Changes");
		System.out.println(stringbuffer);
	}

}
