package day13programs;

public class InsertDemo {

	public static void main(String[] args) {
		String string1;
		int num1 = 2023;
		StringBuffer stringbuffer = new StringBuffer("Original Value");
		System.out.println(stringbuffer);
	    string1 = stringbuffer.append(" num1 = ").append(num1).append(" !!!").toString(); //tostring is used for converting stringbuffer to string
		System.out.println(string1);
		stringbuffer.append(" Value Changes");
		System.out.println(stringbuffer);
		System.out.println("===================================================");
		StringBuffer stringbuffer1 = new StringBuffer("I Java !!!");
		stringbuffer1.insert(2, "Love");
		System.out.println(stringbuffer1);
		stringbuffer1.insert(2, string1);
		System.out.println(stringbuffer1);
		System.out.println(stringbuffer1.reverse());
		System.out.println("===================================================delete()");
		StringBuffer stringbuffer2 = new StringBuffer("Hello All !!! My Name is Micheal");
		System.out.println(stringbuffer2);
		System.out.println(stringbuffer2.delete(5, 24));
		System.out.println("===================================================deleteCharAt()");
		StringBuffer stringbuffer3 = new StringBuffer("Hello All !!! My Name is Micheal");
		System.out.println(stringbuffer3);
		System.out.println(stringbuffer3.deleteCharAt(22));
		System.out.println("===================================================replace()");
		System.out.println(stringbuffer2);
		System.out.println(stringbuffer2.replace(6,  15,  "Bala"));
		System.out.println("===================================================substring()");
		System.out.println(stringbuffer2);
		System.out.println(stringbuffer2.substring(6,10));
		System.out.println("===================================================");
		System.out.println(stringbuffer3);
		System.out.println(stringbuffer3.substring(6,10));

		
		
	}
}

