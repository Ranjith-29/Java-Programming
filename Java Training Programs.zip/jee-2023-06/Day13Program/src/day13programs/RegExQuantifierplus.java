package day13programs;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class RegExQuantifierplus {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("B+"); ///Quantifier plus
		Matcher matcher1 = pattern.matcher("B in BB the BBBBBB b BBB beee BBBBBBB beeee BBBBBBBBBBBBB");
        while(matcher1.find()) {
        	System.out.println("Match Found: "+ matcher1.group());
        }
	}

}
