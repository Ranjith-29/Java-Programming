package day13programs;

public class TwoArgGenMain {

	public static void main(String[] args) {
		TwoArgGen<Integer, String> tagobj = new TwoArgGen<Integer, String>(100,"sachin");
		tagobj.showType();
		int intval = tagobj.gettObj();
		System.out.println("int value "+intval);
		System.out.println("String value "+tagobj.getObj());

	}

}
