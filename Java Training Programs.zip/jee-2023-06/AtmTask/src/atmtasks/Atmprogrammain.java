package atmtasks;
import java.util.Scanner;
public class Atmprogrammain  {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Atmprogram4 obj = new Atmprogram4 ("Kamal Hassan",83217,9790878524L,200000,4321);
		Atmprogram4 obj1 = new Atmprogram4 ("Rolex Suriya",43212,8575421300L,200000,3452);
		Atmprogram4 obj2 = new Atmprogram4 ("Thalapthy Leo",74321,8575421301L,200000,3456);
		obj1.Welcome();
		   System.out.print("Enter your Account number: ");
		   int confirmAccno = s.nextInt();
		  /* System.out.print("Enter your Pinnumber: ");
		   int confirmPin = s.nextInt(); */
		   if( confirmAccno == obj.Accnum ) /*&& confirmPin == obj.pin) */ {
			   System.out.println("\nCustomer 1 Details\n");
			   System.out.println("Happie to see " +obj.Holdername+"\n");
			   System.out.println("Accnum: "+obj.Accnum);
			   System.out.println("Mobnum: "+obj.Mobnum);
			   System.out.println("Bal   : "+obj.Bal);
				int option,var=1;
				while(var == 1) {    
					System.out.print("\n1. Withdraw"+"     3. ViewBalance"+"\n\n2. Deposit"+"      4. Quit"+"\n\nPress 1 for --> withdraw"+"\nPress 2 for --> Deposit"+"\nPress 3 for --> ViewingBalance"+"\nPress 4 for --> Quiting from Console."+"\nChoose your choice: ");
					option = s.nextInt();
					switch(option) {
					case 1: obj.Withdraw();break;
					case 2: obj.Deposit();break;
					case 3: obj.viewBalance();break;
					default : --var; System.out.println("Thank you Visit Again");
					}
	 			}
		   }
		   
				else if(confirmAccno == obj1.Accnum)/* && confirmPin == obj1.pin) */ {
					   System.out.println("\nCustomer 2 Details:\n");
					   System.out.println("Happie to see  " +obj1.Holdername+"\n");
					   System.out.println("Accnum: "+obj1.Accnum);
					   System.out.println("Mobnum: "+obj1.Mobnum);
					   System.out.println("Bal: "+obj1.Bal);
						int option,var=1;
						while(var == 1) {
							System.out.print("\n1. Withdraw"+"     3. ViewBalance"+"\n\n2. Deposit"+"      4. Quit"+"\n\nPress 1 for --> withdraw"+"\nPress 2 for --> Deposit"+"\nPress 3 for --> ViewingBalance"+"\nPress 4 for --> Quiting from Console."+"\nChoose your choice: ");
							option = s.nextInt();
							switch(option) {
							case 1: obj.Withdraw();break;
							case 2: obj.Deposit();break;
							case 3: obj1.viewBalance();break;
							default : --var; System.out.println("Thank you Visit Again");
							}
			 			}
			}
				else if(confirmAccno == obj2.Accnum)/* && confirmPin == obj2.pin)*/ {
					   System.out.println("\nCustomer 3 Details\n");
					   System.out.println("Happie to see " +obj2.Holdername+"\n");
					   System.out.println("Accnum: "+obj2.Accnum);
					   System.out.println("Mobnum: "+obj2.Mobnum);
					   System.out.println("Bal: "+obj2.Bal);
						int option,var=1;
						while(var == 1) {
							System.out.print("\n1. Withdraw"+"     3. ViewBalance"+"\n\n2. Deposit"+"      4. Quit"+"\n\nPress 1 for --> withdraw"+"\nPress 2 for --> Deposit"+"\nPress 3 for --> ViewingBalance"+"\nPress 4 for --> Quiting from Console."+"\nChoose your choice: ");
							option = s.nextInt();
							switch(option) {
							case 1: obj.Withdraw();break;
							case 2: obj.Deposit();break;
							case 3: obj2.viewBalance();break;
							default : --var; System.out.println("Thank you Visit Again");
							}
			 			}
			}
			else {
				System.out.println("\nEntered details are incorrect "+"\nPlease check the details entered. ");
			}
			
		}

		
	}

