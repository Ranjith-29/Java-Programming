package atmtasks;

public class Atmprogram4 extends Atmprogram3{
	
		
		Atmprogram4(String Holdername,int Accno,long Mobno,int Bal,int pin)
		{
			super(Holdername,Accno,Mobno,Bal,pin);
		}
		void Welcome(String str) {
			System.out.println(str+"Welcome to Doobakuru Bank");
	
		}

}
