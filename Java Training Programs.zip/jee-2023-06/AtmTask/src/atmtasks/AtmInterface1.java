package atmtasks;

public interface AtmInterface1 extends AtmInterface {
	void Withdraw();
	void Deposit();

}
