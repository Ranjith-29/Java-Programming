package atmtasks;

import java.util.Scanner;

public class Atmprogram2 extends Atmprogram1 {
	Scanner s = new Scanner(System.in);

	Atmprogram2(String Holdername, int Accnum, Long Mobnum, int Bal, int pin) {
		super(Holdername, Accnum, Mobnum, Bal, pin);
	}

	{
		this.Holdername = Holdername;
		this.Accnum = Accnum;
		this.Mobnum = Mobnum;
		this.Bal = Bal;
		this.pin = pin;
	}

	 void Welcome(String str) {
		System.out.println(str+"Welcome to Doobakuru Bank");

	}

	void viewBalance() {
		System.out.println("Your Bank Balance is "+this.Bal+"/-");
		
	}


}
