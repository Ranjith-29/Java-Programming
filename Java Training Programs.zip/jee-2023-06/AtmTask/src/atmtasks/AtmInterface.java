package atmtasks;

public interface AtmInterface {

	void Welcome();
}  
