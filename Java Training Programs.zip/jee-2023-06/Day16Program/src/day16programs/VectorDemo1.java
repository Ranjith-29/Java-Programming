package day16programs;

import java.util.Vector;
import java.util.Enumeration;


public class VectorDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Integer> vector = new Vector<Integer>(3,3);
		System.out.println("Initial Size : " + vector.size());
		System.out.println("Initial Capacity : " + vector.capacity());
		vector.addElement(22);
		vector.addElement(99);
		vector.add(77);
		System.out.println("After  3 additions Size is : " + vector.size());
		System.out.println("After  3 additions Capacity is : " + vector.capacity());
        vector.add(1000);
        System.out.println("After  4 additions Size is : " + vector.size());
		System.out.println("After  4 additions Capacity is : " + vector.capacity());
		
		System.out.println("first Element: "+vector.firstElement());
		System.out.println("first Element: "+vector.lastElement());
		
		Enumeration venum = vector.elements();
		System.out.print("Vector elements: ");
		while(venum.hasMoreElements()){
			System.out.print(venum.nextElement() + " ");
		
		
		
	}

	}

}
