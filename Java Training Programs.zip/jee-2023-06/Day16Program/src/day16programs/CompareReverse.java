package day16programs;

import java.util.TreeSet;
import java.util.Comparator;

public class CompareReverse implements Comparator<String>{
	
	@Override
	public int compare(String o1, String o2) {
		return o2.compareTo(o1);
	}
    public static void main(String[] args) {
		
    	TreeSet<String> treeset = new TreeSet<String>(new CompareReverse());
    	treeset.add("Calcutta");
    	treeset.add("Mumbai");
    	treeset.add("Delhi");
    	treeset.add("Hydrabed");
    	treeset.add("Pune");
    	
    	for(String element: treeset) {
    		System.out.print(element + " ");
    	}

	}

}
