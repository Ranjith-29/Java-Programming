package day16programs;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		TreeMap<String, Double> treemap = new TreeMap<String, Double>();
		treemap.put("Mary", 10000.00);
		treemap.put("Tanya", 23000.25);
		treemap.put("Swetha", 99989.00);
		treemap.put("Rahul", 32989.56);
		
		Set<Map.Entry<String, Double>> set = treemap.entrySet();
		for(Map.Entry<String, Double> mapentry: set) {
			System.out.println(mapentry.getKey()+ ": ");
			System.out.println(mapentry.getValue());		
		}
		double balance = treemap.get("Tanya");
		treemap.put("Tanya", balance + 100000);
		{
			System.out.println("Tanya's new balance is : "+ treemap.get("Tanya"));
		}
		
	}

}
