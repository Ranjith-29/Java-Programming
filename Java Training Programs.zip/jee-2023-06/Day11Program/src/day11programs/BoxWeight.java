package day11programs;

public class BoxWeight extends Box {
	double weight; 
	
	BoxWeight(BoxWeight ob){
		super(ob);
		weight = ob.weight;
	}
    BoxWeight(double length,double weight){ //3rd done this 
    	super(length);
    	this.weight = weight;
    }
    
	BoxWeight(double width, double height, double depth,double weight) { //2nd done this 
		super(width, height, depth);
		this.weight = weight;
		
	}

	BoxWeight() {
		super();     //1st done this 
		weight = 10;
	} 

}
