package sba3taxi;
import java.util.Scanner;
public class cabLogin{
	Scanner scanner = new Scanner(System.in);
      
	 public  void createAccount() {
	    Scanner scanner = new Scanner(System.in);
	    String phoneNumber = scanner.nextLine();
	      if(phoneNumber.equals("9344654319")) {
		     System.out.println("Account created");
	      }else {
		     System.out.println("Invalid phone number.Please try again");
		     createAccount();
	      }
	 } 
	 public boolean userCancel() {
		 Boolean cancellationFee = false;
		 System.out.println("Mention time of cancellation(int minutes)");
		 int time = scanner.nextInt();
		 if(time<=30) {
			 System.out.println("No need to pay cancellation fee");
			 return cancellationFee;
		 }else {
			 int charge = (int)(Math.random() * 500)+1;
			 System.out.println("Cancellation charge of $: "+charge);
			 cancellationFee = true;
			 return cancellationFee;
		 }
	 }
		
		    	
		       	 
}


