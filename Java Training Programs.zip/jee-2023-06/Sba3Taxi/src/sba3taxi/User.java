package sba3taxi;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public  class User extends cabDetail {
	/*	protected String email;
		protected String password;
		protected abstract String  getemail();
		protected abstract String  getpassword();
		
		User(String email,String password ) {
			
			this.email=email;
			this.password=password;
			
		} */
	    private String name;
		private String username;
		private String mobnumber;
		private String gender;
		private String useremail;
		private String userpassword;
		public static ArrayList<String> usernames=new ArrayList<>();
		public static ArrayList<String> password=new ArrayList<>();
		public static ArrayList<String> names=new ArrayList<>();
		public static ArrayList<String> mobnum=new ArrayList<>();
	//	public static ArrayList<String> gend=new ArrayList<>();

		public User(String name,String username,String mobnumber,String useremail, String userpassword) {

		//super (username,useremail,userpassword);
        this.name = name;
		this.username = username;
        this.mobnumber = mobnumber;
      //  this.gender = gender;
		this.useremail = useremail;
		this.userpassword = userpassword;

		}

		public String getName() {
			return name;
		}

		public String getUsername() {
			return username;
		}

		public String getMobnumber() {
			return mobnumber;
		}
	//	public String getGender() {
	//		return gender;
	//	} 
		public String getUseremail() {
			return useremail;
		}
		public String getUserpassword() {
			return userpassword;
		}

		public static boolean recoverAccount(String username) {

		Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}");

		Matcher matcher = pattern.matcher(username);

		if (matcher.matches()) {

		System.out.println("A recovery user id: " + username);

		return true;

		} else {

		System.out.println("Invalid email format");

		return false;

		}

	} 
}
