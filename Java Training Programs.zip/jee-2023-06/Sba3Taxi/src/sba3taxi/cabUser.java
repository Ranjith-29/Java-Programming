package sba3taxi;
import java.util.Scanner;
/*public  class cabUser extends User {
    Scanner scanner=new Scanner(System.in);
	
	public cabUser(String email,String password){
		super(email,password);
		this.email = email;
		this.password=password;
			
	}
	public String getemail() {
		return email;
	}
	public String getpassword() {
		return password;
	} 
}*/



