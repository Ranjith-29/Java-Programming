package sba3taxi;

public class DriverDetails {


	public String driverName;
    public String cabModel;
    public String cabNumber;
    
    public DriverDetails(String driverName, String cabModel,String cabNumber) {
    	this.driverName= driverName;
    	this.cabModel = cabModel;
    	this.cabNumber = cabNumber;
    }
}


