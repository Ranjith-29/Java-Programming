package sba3taxi;
import java.util.Scanner;
public class cabDetail extends cabLogin {
	Scanner scanner = new Scanner (System.in);
	String driverName = "Suresh";
	String cabNumber = "Tn45A6678";
	String cabModel =  "Innova";
	String ans;
	public void bookCab() {
		System.out.println("Shall i confirm your ride with us (yes/no)");
		String ans = scanner.next();
		if(ans == "yes") {
			System.out.println("Driver Name: " +driverName);
			System.out.println("Cab Number : " +cabNumber);
			System.out.println("Cab Model  : " +cabModel);
		}
		else if (ans == "no") {
			boolean  cancellationFee = false;
			 System.out.println("Mention time of cancellation(int minutes)");
			 int time = scanner.nextInt();
			 if(time<=30) {
				 System.out.println("No need to pay cancellation fee");
			 }else {
				 int charge = (int)(Math.random() * 500)+1;
				 System.out.println("Cancellation charge of $: "+charge);
				 cancellationFee = true;
		}
	}
	}

	
	public void changeLocation() {
		System.out.println("choose 1 to confirm new location");
		System.out.println("choose 2 to not change the location");
		int newLocation = scanner.nextInt();
		switch(newLocation) {
		case 1:
			System.out.println("select your new destination from below options");
			String changeLocation = scanner.nextLine();
			break;
		case 2:
			System.out.println("i dont want to change destination");
            break;
		}
	}

	public void tipChoice() { 
	     int tipPercentage;
		System.out.println("Enter tip amount(int percentage): ");
		tipPercentage=scanner.nextInt();

	}

}

