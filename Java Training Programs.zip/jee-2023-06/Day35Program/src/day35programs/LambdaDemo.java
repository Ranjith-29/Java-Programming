package day35programs;

public class LambdaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
