package day7programs;

public class ForEachDemo {

	public static void main(String[] args) {
		int nums[] = {44,56,59,109,200};
		int sum = 0;
		for(int ctr: nums) {
			System.out.println(ctr);
			sum += ctr;
			System.out.println("Sum now: "+ sum);
		}
		System.out.println("Final sum: "+ sum);

	}

}
