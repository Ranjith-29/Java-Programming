package day7programs;

public class Circle1 {
	double radius;
	double Area;
	double Area1;
	double circumference;
	double circumference1;
	Circle1(double r1) {
		radius = r1;
	}
	void solution(){
		Area = 3.14*radius*radius;
		System.out.println("Total sum of equation in void type is: "+"Area of Circle: "+Area);
	}
	double equationValue(){
		Area1 = 3.14*radius*radius;
		return Area1;
	}
    void solution1(){
		circumference = 2*3.14*radius;
		System.out.println("Total sum of equation in void type is: "+"Circumference of Circle: "+circumference);
	}
    double equationValue1(){
		circumference1 = 2*3.14*radius;
		return circumference1;
	}


}
