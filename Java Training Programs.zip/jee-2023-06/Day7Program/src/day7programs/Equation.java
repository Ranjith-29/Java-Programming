package day7programs;

public class Equation {
	float a,b,c,m;
	void var(float a1,float b1,float c1){
		a = a1;
		b = b1;
		c = c1;
	}
	float equationValue(){
		m = (3*a)+(5*b)-c;
		return m;
	}
}

//function with args(initialize) + return function(calculation)