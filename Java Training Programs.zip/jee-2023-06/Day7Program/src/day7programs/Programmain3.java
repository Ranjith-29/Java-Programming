package day7programs;

public class Programmain3 {

	public static void main(String[] args) {
		Program1 eq = new Program1(5,10,15);
		eq.solution();
		System.out.println("Total sum of equation in return type is : "+eq.equationValue()); // TODO Auto-generated method stub


	}

}
