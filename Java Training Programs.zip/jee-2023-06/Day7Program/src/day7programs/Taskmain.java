package day7programs;

public class Taskmain {

	public static void main(String[] args) {
		Task eq = new Task();
		eq.var(5,10,15,20);
		System.out.println("m Value is : "+eq.equationValue());

	}

}
