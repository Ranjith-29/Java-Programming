package day7programs;

public class Constructormain {

	public static void main(String[] args) {
		Constructor sqr1 = new Constructor(10);
		Constructor sqr2 = new Constructor(15);
		Constructor sqr3 = new Constructor(20);
		
		//sqr1.side = 10;
        //sqr2.side = 15;
       //sqr3.side = 20;
        
        //sqr1.sideInit(10);  //object.variable = value using function
        //sqr2.sideInit(15); 
        //sqr3.sideInit(20); 
        
        sqr1.squareArea(); //object.function()
        sqr2.squareArea();
        sqr3.squareArea();
       
       System.out.println("Perimeter: "+sqr1.squarePerimeter()); 
       System.out.println("Perimeter: "+sqr2.squarePerimeter()); 
       System.out.println("Perimeter: "+sqr3.squarePerimeter()); 
       
	}

}

