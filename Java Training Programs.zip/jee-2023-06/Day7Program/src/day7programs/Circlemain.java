package day7programs;

public class Circlemain {

	public static void main(String[] args) {
		Circle eq = new Circle();
		Circle eq1 = new Circle();
		Circle eq2 = new Circle();
		eq.var(3.56);
		eq1.var(12.22);
		eq2.var(23.456);
		System.out.println("The Area of the Circle : "+eq.equationValue());
		System.out.println("The Area of the Circle : "+eq1.equationValue());
		System.out.println("The Area of the Circle : "+eq2.equationValue());
		System.out.println("==================================================");
		System.out.println("The Area of the Circumference : "+eq.equationValue1());
		System.out.println("The Area of the Circumference : "+eq1.equationValue1());
		System.out.println("The Area of the Circumference : "+eq2.equationValue1());// TODO Auto-generated method stub

	}

}
