package day7programs;

public class Equationmain {

	public static void main(String[] args) {
		Equation eq = new Equation();
		eq.var(5,10,15);
		System.out.println("m Value is : "+eq.equationValue()); 

	}

}
