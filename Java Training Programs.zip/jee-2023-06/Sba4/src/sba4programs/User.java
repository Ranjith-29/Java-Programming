package sba4programs;

public  class User extends CreateAccount {
		public String upiId;
		public String Name;
		public String mobileNumber;
		public int Acc_num;
		public String Acc_type;
		public double balance;
		public User(String upiId,String Name,String mobileNumber,int Acc_num, String Acc_type,double balance) {	
			this.upiId = upiId;
			this.Name = Name;
			this.mobileNumber = mobileNumber;
			this.Acc_num = Acc_num;
			this.Acc_type = Acc_type;
			this.balance=balance;
			
			
		}
		public String getUpiId() {
			return upiId;
		}
		public void setUpiId(String upiId) {
			this.upiId = upiId;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public int getAcc_num() {
			return Acc_num;
		}
		public void setAcc_num(int acc_num) {
			Acc_num = acc_num;
		}
		public String getAcc_type() {
			return Acc_type;
		}
		public void setAcc_type(String acc_type) {
			Acc_type = acc_type;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}

		public static void deposit(User user,double depositAmount) {
			user.setBalance(user.getBalance() + depositAmount);
			System.out.println("Amount successfully Deposited "+"\nbalance is: " + user.getBalance());
		}
		public static void withdraw(User user,double withdrawAmount) {
			user.setBalance(user.getBalance() - withdrawAmount);
			System.out.println("Amount successfully Withdrawn "+"\nbalance is: " + user.getBalance());
		} 
		void Welcome(String str) {
			System.out.println(str+ANSI_PURPLE+"Hey , You Chosen Great Kerigalan Magic Hi-fi Service Bank"+ANSI_RESET);
	
		}

		

}
