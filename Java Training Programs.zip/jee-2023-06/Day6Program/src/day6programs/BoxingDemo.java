package day6programs;

public class BoxingDemo {

	public static void main(String[] args) {
		@SuppressWarnings("removal")
		int num1 = 200;
		Integer iob =  Integer.valueOf(num1); //boxing
		int i = iob.intValue(); //unboxing
		System.out.println("i: "+i);
		System.out.println("iob: "+iob);
	}

}
