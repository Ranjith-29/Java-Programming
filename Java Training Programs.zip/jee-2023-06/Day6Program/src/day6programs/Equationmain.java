package day6programs;

public class Equationmain {

	public static void main(String[] args) {
		Equation Eq = new Equation();// this line is for creating a space for each variable
		Equation Eq1 = new Equation();
		Equation Eq2 = new Equation();
		
		Eq.y = 2; //this assiging the value to the variable
		Eq.z = 3;
		Eq.m = 5;
		
		Eq1.y = 5; //this assiging the value to the variable for another object
		Eq1.z = 10;
		Eq1.m = 15;
		
		Eq2.y = 6; //this assiging the value to the variable
		Eq2.z = 3;
		Eq2.m = 2;
		
		Eq.SolveEquation(); //method call
		Eq1.SolveEquation();
		Eq2.SolveEquation(); 
	}

}
