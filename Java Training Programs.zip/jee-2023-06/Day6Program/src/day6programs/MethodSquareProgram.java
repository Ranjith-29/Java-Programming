package day6programs;

public class MethodSquareProgram {
	float side; 
	float area;
	float perimeter;
	void squareArea() {
		 area = side * side;
		 System.out.println("Area of Square is: "+area);
		}
	void squarePerimeter() {
		 perimeter = 4 * side;
		 System.out.println("Perimeter of Square is: "+perimeter);		 
	}
}
