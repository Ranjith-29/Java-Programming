package day6programs;

public class Equation {
	double x,y,z,m;
	void SolveEquation() {
		x = (y*y + z*z)/m; //(y2+z2)/m
		System.out.println("End value is: "+x); 
		
	}
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               

}
