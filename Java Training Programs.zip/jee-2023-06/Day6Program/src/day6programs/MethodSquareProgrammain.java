package day6programs;

public class MethodSquareProgrammain {

	public static void main(String[] args) {
		MethodSquareProgram sqr1 = new MethodSquareProgram();
		MethodSquareProgram sqr2 = new MethodSquareProgram();
		MethodSquareProgram sqr3 = new MethodSquareProgram(); 
		
        sqr1.side = 10;
        sqr2.side = 15;
        sqr3.side = 20; //object.variable = value
        
        sqr1.squareArea(); //object.function()
        sqr1.squarePerimeter();
       
        sqr2.squareArea();
        sqr2.squarePerimeter();
       
        sqr3.squareArea();
        sqr3.squarePerimeter();
                         
	}

}
