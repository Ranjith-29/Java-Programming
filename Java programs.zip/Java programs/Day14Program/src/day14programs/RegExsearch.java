package day14programs;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class RegExsearch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String regex = "Monkey";
		System.out.println("Enter a  String values for the Pattern");
		String str = sc.nextLine();
		Pattern pattern =  Pattern.compile(regex);
		Matcher matcher1 = pattern.matcher(str);
	/*	if(matcher1.find()) {
			System.out.println("found");
		}
		else {
			System.out.println("Not Found");
		} */
		while(matcher1.find()) {
			System.out.println(matcher1.group() + " is matched from "+matcher1.start() + " to "+matcher1.end());
		}

		
	}

}
