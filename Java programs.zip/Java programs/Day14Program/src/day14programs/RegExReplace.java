package day14programs;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExReplace {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String regex = "Monkey";
		System.out.println("Enter a  String values for the Pattern");
		String str = sc.nextLine();
		Pattern pattern =  Pattern.compile(regex);
		Matcher matcher1 = pattern.matcher(str);
		System.out.println(matcher1.replaceAll("donkey"));
	}

}
