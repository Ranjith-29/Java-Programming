package day14programs;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegExnum {

	public static void main(String[] args) {
		Pattern pattern =  Pattern.compile("[1-100]");
		Matcher matcher1 = pattern.matcher("We are 53 in  14 enjoyment 100 mood ");
		if(matcher1.find()) {
			System.out.println("found Number is there");
		}
		else {
			System.out.println("found Number is not there");
		}

	}

}
