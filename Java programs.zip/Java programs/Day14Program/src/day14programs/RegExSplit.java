package day14programs;

import java.util.regex.Pattern;

public class RegExSplit {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("[ ,.!]");
		String strs[] = pattern.split("Hello World,Welcome to Regex.Using!Split");
		for(int ctr=0; ctr<strs.length; ctr++) {
			System.out.println("Token: "+ctr+ " : "+strs[ctr]);
		}

	}

}
