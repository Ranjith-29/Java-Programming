package day14programs;
//RegexReplaceall_mike Program
import java.util.regex.Matcher;
import java.util.regex.Pattern;
   
public class Replce2RegEx {

	public static void main(String[] args) {
		String str = "Mad is Maddy when Madhan becomes Madhesh";
		Pattern pat = Pattern.compile("Mad.*? ");
		Matcher mat = pat.matcher(str);
        System.out.println("Original Sequence: "+ str);
        str = mat.replaceAll("Mike ");
        System.out.println("Replacment Sequence: "+ str);
	}

}
