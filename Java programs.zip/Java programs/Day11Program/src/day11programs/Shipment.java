package day11programs;

public class Shipment extends BoxWeight {
	double cost;
	String color;
	Shipment(double length, double weight, double cost, String color){
		super(length,weight);
		this.cost = cost;
		this.color = color;
	}
	
         
}
