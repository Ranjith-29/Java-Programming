package day11programs;

public class Box {
	private double width; //1st done this 
	private double height;
	private double depth;
	
	
	Box(Box ob){
		width = ob.width;
		height = ob.height;
		depth = ob.depth;
	}
	Box(double length){ //3rd done this 
		width = height = depth =  length;
	}
	Box(double width, double height, double depth){ //2nd done this 
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	Box(){ //1st done this 
		width = 1;
		height = 1;
		depth = 1;
	} 
	double volume() { //1st done this 
		return width * height * depth;
	}
	

}
