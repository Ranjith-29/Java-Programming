package day11programs;

public class BoxMain {

	public static void main(String[] args) {
		System.out.println("=============================");
		BoxWeight boxweight2 = new BoxWeight(20,25); //3rd done this 
		System.out.println("Volume is "+boxweight2.volume());
		System.out.println("Weight is "+boxweight2.weight);
		System.out.println("================================");
		BoxWeight boxweightObj = new BoxWeight(boxweight2); //4th done this 
		System.out.println("Volume is "+boxweightObj.volume());
		System.out.println("Weight is "+boxweightObj.weight); 
		System.out.println("================================");
		BoxWeight boxweight = new BoxWeight();
		System.out.println("Volume is "+boxweight.volume()); //1st done this 
		System.out.println("Weight is "+boxweight.weight); 
		System.out.println("================================");
		BoxWeight boxweight1 = new BoxWeight(10,15,20,21); //2nd done this 
		System.out.println("Volume is "+boxweight1.volume());
		System.out.println("Weight is "+boxweight1.weight);
		System.out.println("================================");
		Shipment shipment = new Shipment(1,10,10000,"Blue");
		System.out.println("Volume  of Shipment is "+shipment.volume());
		System.out.println("Weight of Shipment "+shipment.weight);
		System.out.println("Cost of Shipment "+shipment.cost);
		System.out.println("Color of Shipment is "+shipment.color);
		System.out.println("================================");
		Shipment shipment1 = new Shipment(22,21,15000,"Green");
		System.out.println("Volume  of Shipment2 is "+shipment1.volume());
		System.out.println("Weight of Shipment2 "+shipment1.weight);
		System.out.println("Cost of Shipment2 "+shipment1.cost);
		System.out.println("Color of Shipment2 is "+shipment1.color);
		System.out.println("================================");
		Shipment shipment2 = new Shipment(20,25,20000,"Red");
		System.out.println("Volume  of Shipment3 is "+shipment2.volume());
		System.out.println("Weight of Shipment3 "+shipment2.weight);
		System.out.println("Cost of Shipment3 "+shipment2.cost);
		System.out.println("Color of Shipment3 is "+shipment2.color);
		System.out.println("================================");
		Shipment shipment3 = new Shipment(20,25,20000,"Black");
		System.out.println("Volume  of ShipmentObj is "+shipment2.volume());
		System.out.println("Weight of ShipmentObj "+shipment2.weight);
		System.out.println("Cost of ShipmentObj "+shipment2.cost);
		System.out.println("Color of ShipmentObj is "+shipment2.color);
		
		
		
		
		
		

	}

}
