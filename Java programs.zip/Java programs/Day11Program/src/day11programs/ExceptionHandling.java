package day11programs;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionHandling {

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the distance travelled: ");
			int distance = sc.nextInt();
			System.out.println("Enter the Time Travelled: ");
			int time1 = sc.nextInt();
			System.out.println("Distance travelled is: "+ distance);
			System.out.println("Time  travelled is : "+ time1);
			System.out.println("Speed is : "+ (distance/time1)+ " mps");
	//		throw new ArithmeticException();
	//		throw new InputMismatchException();
			throw new ArrayIndexOutOfBoundsException(); //throw used for What Exception the code is getting we can see that or To manually throw Exception
	//		 int myArray[] = {2,5,7,9,20022};
		//	 myArray[23] = 2022;
			
		} catch(ArithmeticException | InputMismatchException | ArrayIndexOutOfBoundsException exception) {
			/*catch is used when we know that code is getting arithmetiuc exception but to run that code we use catch*/
			System.out.println("Exception Caught "+exception);
		} 
	/*	catch (InputMismatchException ime) {
			System.out.println("Please Check your input: Exception is "+ime);
		} */
		int ctr = 0;
		while(ctr < 10) {
			System.out.println(ctr+" ");
			ctr++;
		}
	}  

}
