package day17programs;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
