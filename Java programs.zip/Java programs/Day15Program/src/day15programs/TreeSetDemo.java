package day15programs;
//import java.util.HashSet;
import java.util.TreeSet;
import java.util.Comparator;
public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<String> treeset  = new TreeSet<String>();
		treeset.add("Blue");
		treeset.add("Red");
		treeset.add("Green");
		treeset.add("Yellow");
		treeset.add("Orange");
		System.out.println("TreeSet: "+treeset);
	/*	Comparator<?> comparator = new treeset.comparator(); */
		

	}

}
