package day15programs;
import java.util.LinkedList;
public class MailingList {

	public static void main(String[] args) {
		LinkedList<Address> mail = new LinkedList<Address>();
		mail.add(new Address("Bala", "12", "windsor road", "London", "London", "E7 3AB"));
		mail.add(new Address("Sam", "14", "Gandhi Nagar", "Hyderabad", "Telangana", "500001"));
		mail.add(new Address("Ram", "15", "Thilai Nagar", "Trichy", "Tamilnadu", "500001"));
		mail.add(new Address("Thamu", "14", "Gandhi Nagar", "Hyderabad", "Tamilnadu", "500001"));
		mail.add(new Address("Sam", "14", "Gandhi Nagar", "Hyderabad", "Telangana", "500001"));
		mail.add(new Address("Sreemathi", "17", "Gandhi Nagar", "Hyderabad", "Telangana", "500001"));
		//5 more addresses
		for(Address address : mail) {
			System.out.println(address +"\n");
		}

	}

}
