package day15programs;
import java.util.HashSet;
public class HashSetDemo {

	public static void main(String[] args) {
		HashSet<String> hashset = new HashSet<String>();// TODO Auto-generated method stub
        hashset.add("Merc");
        hashset.add("BMW");
        hashset.add("Ford Mustang");
        hashset.add("Rolls Royce");
        System.out.println("Hashset: "+hashset);
        HashSet<String> hashset1 = new HashSet<String>(hashset);
        hashset1.add("Renault");
        System.out.println("Hashset1: "+hashset1);
        
        
	}

}
