package day8programs;

public class Overload2main {

	public static void main(String[] args) {
		Overload2 overload = new Overload2();
		double result;
		//call all version of test()
		 overload.test();
		 overload.test(10);
		 overload.test(10,20);
		 result = overload.test(123.25);
		 System.out.println("Result of overload.test(123.25): " +result);
	}

}
