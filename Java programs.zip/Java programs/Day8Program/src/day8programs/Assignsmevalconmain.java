package day8programs;

public class Assignsmevalconmain {

	public static void main(String[] args) {
		Assignsmevalcon sqr1 = new Assignsmevalcon(10);
		Assignsmevalcon sqr2 = new Assignsmevalcon(15);
		Assignsmevalcon sqr3 = new Assignsmevalcon(20);
		sqr1.squareArea();
		sqr2.squareArea();
		sqr3.squareArea();
	    System.out.println("Perimeter of Square is: "+sqr1.squareperimeter()); 
	    System.out.println("Perimeter of Square is: "+sqr2.squareperimeter());    
	    System.out.println("Perimeter of Square is: "+sqr3.squareperimeter());   
	       
	}

}
