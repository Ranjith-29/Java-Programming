package day8programs;

public class Assignsmevalcon {
	float side, area, perimeter;
	Assignsmevalcon(float side){
		this.side = side;
	}
	void squareArea() {
		area = side * side;
		System.out.println("Area of square is: "+ area);
	}
	float squareperimeter() {
		perimeter = 4* side;
		return perimeter;
	}

}
