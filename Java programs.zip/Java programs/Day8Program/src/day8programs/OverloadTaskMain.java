package day8programs;

public class OverloadTaskMain {

	public static void main(String[] args) {
		OverloadTask overloadtask = new OverloadTask();
		overloadtask.sum(2,3);
		overloadtask.sum(2,3,4);
		overloadtask.sum(2,3,5);
	}

}
