package day8programs;
//methodoverload - Polymorphism
public class OverloadMain {

	public static void main(String[] args) {
		OverloadA overload = new OverloadA(20,30);
		overload.sum("Sum of num1 and num2 is: ");
		overload.sum();// TODO Auto-generated method stub

	}

}
