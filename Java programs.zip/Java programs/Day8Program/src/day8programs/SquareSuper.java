package day8programs;
//inheritance program
public class SquareSuper {
	float side, area, perimeter;
	SquareSuper (float side) {
		this.side = side;
		
	}
/*	void sideInit(float side1) {
		side = side1;
	} */
	void squareArea( ) {
		area = side * side;
		System.out.println("Area of Square is: "+area);
	}

}
