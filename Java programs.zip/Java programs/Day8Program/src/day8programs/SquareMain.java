package day8programs;
//inheritance program
public class SquareMain {

	public static void main(String[] args) {
		Square square = new Square();
		//square.sideInit(10);
		square.squareArea();
		System.out.println("Perimeter of a Square: "+square.squarePerimeter());// TODO Auto-generated method stub

	
	   SquareSuper squaresuper = new SquareSuper(20);
	   //squaresuper.sideInit(20);
	   squaresuper.squareArea(); 
	   //System.out.println("Perimeter of a Square: "+squaresuper.squarePerimeter());
	   
	   Square2 square2 = new Square2();	
	   square2.side = 40;
	   //square2.sideInit(15);
	   square2.squareArea(); 
	   System.out.println("Perimeter of a Square: "+square2.squarePerimeter());
	   square2.square2Fn();
	}
	   
}
