package day8programs;
//overriding - Polymorphism
public class OverrideChild extends OverrideSuper {
	void OverrideMethod() {
   	 System.out.println("The Child Class Method");
    }

}
