package day8programs;
//inheritance program
public class Square extends SquareSuper {
	Square(){
		super(10);
	}
	float squarePerimeter( ) {
		perimeter = 4 * side;
		return perimeter;
	}

}
