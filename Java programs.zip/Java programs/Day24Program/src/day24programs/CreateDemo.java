package day24programs;
//import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDemo {

	public static void main(String[] args) {
		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			System.out.println("Driver Loaded");

			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL" , "scott", "tiger"); //ORCL = xe first input

			if(connection == null) {

			System.out.println("Connection not established with Oracle Data Base");

			}else {

			System.out.println("Success.... Connection is estabished with Oracle DB");

			}

			Statement statement = connection.createStatement();

			boolean success = statement.execute("Create table studentdxc(sno number(5), sname varchar(40), branch varchar(40))");

			if(success == false) {

			System.out.println("Student Table create");

			}else {

			System.out.println("error in Table Creation");

			}

			}catch(ClassNotFoundException | SQLException e) {

			e.printStackTrace();

			}
		
	}

}
