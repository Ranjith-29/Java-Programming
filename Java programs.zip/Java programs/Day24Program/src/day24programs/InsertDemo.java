package day24programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner scanner = new Scanner(System.in);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL" , "scott","tiger");
			if(connection == null) {
				System.out.println("Connection not Established With Oracle Data Base");
			}
			else {
				System.out.println("Success....Connection is Established with Oracle DB");
			}
		Statement statement = connection.createStatement();

		System.out.println("Enter Student number : ");

		int sno = scanner.nextInt();

		System.out.println("Enter Student Name :");

		String sname = scanner.next();

		System.out.println("Enter Engineering Branch : ");

		String branch = scanner.next();

		String insertQuery = "insert into studentdxc values (" +sno + ",' " +sname + "','" +branch + " ' )";

		System.out.println(insertQuery);

		int result = statement.executeUpdate(insertQuery);

		if(result == 0) {

		System.out.println("Record not Inserted");

		}else {

		System.out.println("Record inserted into studentdxc table");

		}

		}catch(ClassNotFoundException | SQLException e) {

		e.printStackTrace();

		}


	}

}
