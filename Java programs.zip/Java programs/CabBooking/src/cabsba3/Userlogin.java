package cabsba3;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Userlogin  {
	String userid,pass;
/*	public Userlogin(String userid, String name, String pass, String gender) {
		super(userid, name, pass, gender);
		 // TODO Auto-generated constructor stub
	}  */
	
/*	Userlogin(String userid,String pass){
		this.userid = userid;
		this.pass = pass;
	}  */
	 
/*	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		return "Userlogin [userid=" + userid + ", pass=" + pass + "]";
	} */
	String Drivername,Cabmodel,Cabnumber;
    void Driver() {
    	Drivername = "Abdul";
    	Cabmodel = "Innova";
    	Cabnumber = "Tn451342";
    	
    }
	void JourneyMessage() {
		System.out.println("Welcome to Rockfort City");
	}
    void LoginInput() {
    	    Scanner sc = new Scanner(System.in);
    	    System.out.println("ENTER YOUR USER ID:");
    	    String userId = sc.nextLine();
	    	Pattern pattern = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9._%+-]+\\.[a-zA-Z0-9._%+-]+&$#.[a-zA-Z0-9._%+-]{2,}");
	    	Matcher matcher = pattern.matcher("Ranjith@29");
	    	if(matcher.matches()) {
	    		System.out.println("WoW..! Happie to See You Ranjith");
	    		System.out.println("-----------------------");
	    		 LoginPass();
	    	}else {
	    		System.err.println("Invalid User id");
	    		LoginInput();	
	    	}
    }
    int num = 1;
    void LoginPass() {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter Your Password");
    	 String pass = sc.nextLine();
	    	Pattern pattern = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9._%+-]+\\.[a-zA-Z0-9._%+-]+&$#.[a-zA-Z0-9._%+-]{2,}");
	    	Matcher matcher = pattern.matcher("Ran@rj123");
	    	if(matcher.matches()) {
	    		System.out.println("Continue...!");
	    		System.out.println("-----------------------");
	    	}else if(num == 3) {
	    		System.err.println("Tried 3 attamepts and Account will be locked");
	    			
	    	}
	    	else {
	    		System.err.println("Invalid Password.!  Try Again ");
	    		System.out.println("Please Enter the Valid Password");
	    		num++;
	    		LoginPass();
	    		System.out.println("-----------------------");
	    	}
    	
    }
	
	 
    Scanner sc = new Scanner (System.in);
	String driverName;
	String cabNumber;
	String cabModel;
    void bookCab() {
		System.out.println("Shall i confirm your ride with us (yes/no");
		String confirmation = sc.nextLine();
		System.out.println("Driver Name: " +driverName);
		System.out.println("Cab Number : " +cabNumber);
		System.out.println("Cab Model  : " +cabModel);
    }
    void tipChoice() { 
	     int tipPercentage;
		System.out.println("Enter tip amount(int percentage): ");
		tipPercentage=sc.nextInt();

	}
    void changeLocation() {
		System.out.println("choose 1 to confirm new location");
		System.out.println("choose 2 to not change the location");
		int newLocation = sc.nextInt();
		switch(newLocation) {
		case 1:
			System.out.println("select your new destination from below options");
			String changeLocation = sc.nextLine();
			break;
		case 2:
			System.out.println("i dont want to change destination");
            break;
		}
	}
    public boolean userCancel() {
   	 Boolean cancellationFee = false;
   	 System.out.println("Mention time of cancellation(int minutes)");
   	 int time = sc.nextInt();
   	 if(time<=30) {
   		 System.out.println("No need to pay cancellation fee");
   		 return cancellationFee;
   	 }else {
   		 int charge = (int)(Math.random() * 500)+1;
   		 System.out.println("Cancellation charge of $: "+charge);
   		 cancellationFee = true;
   		 return cancellationFee;
   	 }
   		 
    }
    void Payment() {	 
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Here you go,Payment methods/Options");
    	int pay = sc.nextInt();
    	System.out.println("1.cash\n 2.phonepay\n 3.GooglePay\n 4.paytm");
    	int Option =sc.nextInt();
    	try {
    		switch(Option) {
    		case 1 :
    			System.out.println("paid by cash ");
    			break;
    		case 2 :
    			System.out.println("Amount transferred through  phonepay");
    			break;
    		case 3 :
    			System.out.println("Amount transferred through gpay");
    			break;
    		case 4 :
    			System.out.println("Amount transferred through paytm");
    			break;
    			default : throw new Exception();
    				
    		   }
    	}catch(Exception ae) {
    		System.out.println("Invalid details, try again"+ae);
    	}
    	
       }
    void Location() {
 	   String locate;
 	   Scanner sc = new Scanner(System.in);
 	   System.out.println("Mark your Current Location..!:(MARKED or NO)");
 	   locate = sc.nextLine().toUpperCase();
 	   if(locate.equals("MARKED")) {
 		   System.out.println("Successfully, Your Current Location Marked");
 		   System.out.print("\n");
 		   System.out.print("Are you like to click destination..!");
 	   }else {
 		   System.out.println("Mark Your Location");
 		   Location();		   
 	   
 	   }   
 		   
    }
    int baseFare = 10;
    int rate,totalFare=0;
    void Chooseplace() {
 	   ArrayList<String> list = new ArrayList<String>();
 	   list.add("1.Trichy Central Bus Stand");
 	   list.add("2.Trichy Chathiram Bus Stand");
 	   list.add("3.Trichy Thillai Nagar");
 	   list.add("4.Trichy Thennur");
 	   list.add("5.Trichy Srirangam");
 	   System.out.println("List of places");
	   System.out.println(list);
	   System.out.println("\n");
	   System.out.println("Select the source location");
	   System.out.println("printLocations :"+list);
	   String source=sc.nextLine();
	   System.out.println("select the destination location");
	   System.out.println("printLocations : "+list);
	   String destination=sc.nextLine();
	   if(source.equals("Trichy Central Bus Stand") && destination.equals("Trichy Chathiram Bus Stand") || source.equals("Trichy Chathiram Bus Stand") && destination.equals("Trichy Central Bus Standd")) {
		    int rate = 50;
			int totalFare = rate+rate;
		}else if(source.equals("Trichy Chathiram Bus Stand") && destination.equals("Trichy Thillai Nagar") || source.equals("Trichy Thillai Nagar") && destination.equals("Trichy Chathiram Bus Stand") ) {
			rate = 21;
			totalFare +=rate;
		}else if(source.equals("Trichy Thillai Nagar") && destination.equals("Trichy Thennur") || source.equals("Trichy Thennur") && destination.equals("Trichy Thillai Nagar") ) {
			rate = 35;
			totalFare +=rate;
		}else if(source.equals("Trichy Thennur") && destination.equals("Trichy Srirangam") || source.equals("Trichy Srirangam") && destination.equals("Trichy Thennur" )) {
			rate = 50;
			totalFare +=rate;
		}else {
			System.out.println("Sorry:( we currently  do not provide cab sevice from " + source + " to " + destination + " is $" + rate);
		}	
	    System.out.println("Are you wishing to cancel the ride(yes/no)");
		String decide = sc.nextLine();
		if (decide.equals("yes")) {
			userCancel();
		}
		System.out.println("Do you want to fix the location(Yes/no)");
		String select = sc.nextLine().toLowerCase();
		if(select.equals("yes")) {
		
		Driver myCab = new Driver(" john Doe" , "AB1234","Honda City");
		System.out.println("The fare for your journey from " + source + " to " + destination + " and baseFare is "+ baseFare+ "  total to pay is $" + rate);
	    System.out.println("\n"); 
	    System.out.println("Do you want to change destination?(Yes/no)");
		String confirm = sc.nextLine().toLowerCase();
		if(confirm.equals("yes")) {
		int extraCharge = 20;
		System.out.println("Enter new destination");
		String newdestination =sc.nextLine();
		for(String location :  list) {
			String regex = "\\b" + location + "\\b";
		Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(newdestination);
		if(matcher.find()) {
			System.out.println("Your destination is changed");
			System.out.println("hey,you reache your destination & extra charge is applied for changing destination midway");
			System.out.println("Your fare is $" + totalFare + "(extra charge: $" + extraCharge + ")");
			
			if(rate > 0)	{
		    System.out.println("Do you wanna give tip?(yes/no)");
		    String check=sc.nextLine();
		    System.out.println("Enter tip in percenatge");
		    int tipPercentage = sc.nextInt();
			int tip = (rate * tipPercentage)/100;
			totalFare = rate +  extraCharge + tip;
			System.out.println("\n");
			System.out.println("The fare for your journey from " + source + " to " + destination +  "with " + extraCharge + "and"  + tip + "is  $" + totalFare );
			System.out.println("\n");
			System.out.println("TOTAL AMOUNT TO BE PAID :"+totalFare);
			Payment();
			System.out.println("Thanks for choosing our cab:)");
			return;
			
		}
			System.out.println("Your location doesnt match with our predefine locations");
		}
		}
		}
}
}
}


			
 
