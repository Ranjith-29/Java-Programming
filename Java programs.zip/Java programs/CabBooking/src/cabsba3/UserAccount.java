package cabsba3;

import java.util.regex.Pattern;
import java.util.Scanner;
import java.util.regex.Matcher;

public class UserAccount extends Carcolor {
	String userid,name,pass,gender;
	UserAccount(String userid,String pass){
		this.userid = userid;
		this.pass = pass;
	} 
	
	/*public UserAccount(String userid, String name, String pass, String gender) {
		this.userid = userid;
		this.name = name;
		this.pass = pass;
		this.gender = gender;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "UserAccount [userid=" + userid + ", name=" + name + ", pass=" + pass + ", gender=" + gender + "]";
	} */
	int num = 1;
    void LoginPass() {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter Your Password");
    	 String pass = sc.nextLine();
	    	Pattern pattern = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9._%+-]+\\.[a-zA-Z0-9._%+-]+&$#.[a-zA-Z0-9._%+-]{2,}");
	    	Matcher matcher = pattern.matcher("Ran@rj123");
	    	if(matcher.matches()) {
	    		System.out.println("Continue...!");
	    		System.out.println("-----------------------");
	    	}else if(num == 3) {
	    		System.err.println("Tried 3 attamepts and Account will be locked");
	    			
	    	}
	    	else {
	    		System.err.println("Invalid Password.!  Try Again ");
	    		System.out.println("Please Enter the Valid Password");
	    		num++;
	    		LoginPass();
	    		System.out.println("-----------------------");
	    	}
    	
    }
	
	

}
