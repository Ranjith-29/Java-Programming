package cabsba3;

public class Driver  {
	public String driverName;
    public String cabModel;
    public String cabNumber;
    
    public Driver(String driverName, String cabModel,String cabNumber) {
    	this.driverName= driverName;
    	this.cabModel = cabModel;
    	this.cabNumber = cabNumber;
    }
	

} 
