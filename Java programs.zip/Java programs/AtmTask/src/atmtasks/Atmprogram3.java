package atmtasks;

public class Atmprogram3 extends Atmprogram2 {

	Atmprogram3(String Holdername, int Accno, long Mobno, int Bal, int pin) {
		super(Holdername, Accno, Mobno, Bal, pin);
	}

	{
		this.Holdername = Holdername;
		this.Accnum = Accnum;
		this.Mobnum = Mobnum;
		this.Bal = Bal;
		this.pin = pin;
	}

	public void Welcome() {
		System.out.println("Welcome to Doobakuru Bank");

	}
	void viewBalance() {
		System.out.println("Your Bank Balance is "+this.Bal+"/-");
	}
}
