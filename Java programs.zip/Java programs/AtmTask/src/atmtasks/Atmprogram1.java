package atmtasks;

import java.util.Scanner;

public class Atmprogram1 implements AtmInterface1{
	String Holdername;
	int Accnum, Bal, pin;
    Long Mobnum;
	Scanner s = new Scanner(System.in);
	Atmprogram1(String Holdername, int Accnum, Long Mobnum, int Bal, int pin) {
		this.Holdername = Holdername;
		this.Accnum = Accnum;
		this.Mobnum = Mobnum;
		this.Bal = Bal;
		this.pin = pin;

	}

	@Override
	public void Welcome() {
		System.out.println("Welcome to Doobakuru Bank");

	}

	@Override
    public void Withdraw() {
		System.out.println("Enter amount to Withdraw: ");
		int withdrawAmount = s.nextInt();
		if(withdrawAmount <= this.Bal) 
		{
			System.out.println("Please confirm to withdraw "+withdrawAmount+" Yes / No : ");
			char confirmation = s.next().charAt(0);
			if(confirmation == 'y' || confirmation == 'Y') {
				this.Bal=this.Bal-withdrawAmount;
				System.out.println("Amount successfully Withdrawn "+"\nbalance is "+this.Bal+"/-");
			}
			else
				System.out.println("Request cancelled");
		}
		else 
			System.out.println("Insufficiant balance"+"\nrequested amount can not be withdrawn"+"\nYour balance is "+this.Bal+"/-"+"\nKindly enter the withdraw amount less than "+this.Bal+" for processing your request");

	}

	@Override
    public  void Deposit() {
    	System.out.print("\nMax amount to deposit is 50000/-"+"\nMinimum amount to deposit is 200/-"+"\nEnter amount to deposit: ");
		int depositAmount =  s.nextInt();
		if(200 <= depositAmount && depositAmount <= 50000) {
			System.out.println("Please confirm to deposit "+depositAmount+" Yes / No : ");
			char confirmationForDeposit = s.next().charAt(0);
			if(confirmationForDeposit == 'Y' || confirmationForDeposit == 'y') {
				this.Bal=this.Bal+depositAmount;
				System.out.println("Amount successfully Deposited "+"\n balance is "+this.Bal+"/-");
			}
			else
				System.out.println("Requestion Cancelled");
		}
		else if(depositAmount > 50000) {
			System.out.println("Entered amount for deposit is Exceeding Maximum deposit amount policy of bank"+"\nCan't proceed your request"+"\nPlease enter valid amount for deposit"+"\nMaximum deposit amount is rupees 50000/-");
		}
		else
			System.out.println("Entered amount is Less than Minimum deposit amount policy of bank"+"\nCan not proceed your request"+"\nPlease enter valid amount for deposit"+"\nMinimum deposit amount is rupees 200/-");
	}
	void viewBalance() {
		System.out.println("Your Bank Balance is "+this.Bal+"/-");
	}

	
}
