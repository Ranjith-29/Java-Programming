package day3programs;

import java.util.Scanner;

public class IntEx4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int benz;
		int duster;
		int total;
		System.out.println("Enter the number of Benz");
		benz = sc.nextInt();
		System.out.println("Enter the number of Duster");
		duster = sc.nextInt();
	    total = benz + duster;
		System.out.println("Total: "+total);// TODO Auto-generated method stub

	}

}
