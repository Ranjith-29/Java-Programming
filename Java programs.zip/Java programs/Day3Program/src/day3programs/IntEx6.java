package day3programs;

import java.util.Scanner;

public class IntEx6 {

	public static void main(String[] args) {
		int a,b,c,d,e;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of a");
		a = sc.nextInt();
		System.out.println("Enter the value of b");
		b = sc.nextInt();
		System.out.println("Enter the value of c");
		c = sc.nextInt();
		System.out.println("Enter the value of d");
		d = sc.nextInt();
		e = (2*a+3*b)-(d+c);
		System.out.println("The total is: "+e);

	}

}
