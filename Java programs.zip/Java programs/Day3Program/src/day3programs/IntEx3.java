package day3programs;

public class IntEx3 {

	public static void main(String[] args) {
	   int lightspeed;
	   long days;
	   long seconds;
	   long distance;
	   //approximate speeed of light in miles per second
	   lightspeed = 186000;
	   days = 1000; //specify number of days
	   seconds = days * 24 * 60 * 60; //convert to seconds
	   distance = lightspeed * seconds; //convert to distance;
	   System.out.println("In " +days);
	   System.out.println("days light will travel about");
	   System.out.println(distance+ " miles.");
	   
	   // TODO Auto-generated method stub

	}

}
