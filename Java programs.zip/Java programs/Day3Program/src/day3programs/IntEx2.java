package day3programs;

import java.util.Scanner;

public class IntEx2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int year;
		int num;
		float amount;
	    System.out.println("Enter the customer name");
	    String name = scanner.nextLine();
	    System.out.println("Enter the current year");
	    year = scanner.nextInt();
	    System.out.println("Enter the amount to deposit");
	    amount = scanner.nextFloat();
	    System.out.println("Enter the no of years you wamt to deposit");
	    num = scanner.nextInt();
	    amount = amount*num;
	    System.out.println("getting money: "+amount);
	    year = year+num;
	    System.out.println("year of getting money: "+year);
	    
	    
	    
	    
	    
	    

	}

}
