package day3programs;

import java.util.Scanner;

public class IntEx8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num1,num2;
		System.out.println("Enter the num1");
		num1 = sc.nextInt();
		System.out.println("Enter the num2");
		num2 = sc.nextInt();
		System.out.println("Sum : "+(num1+num2));
		System.out.println("difference : "+(num1-num2));
		System.out.println("Product : "+(num1*num2));
		System.out.println("Remainder : "+(num1/num2));// TODO Auto-generated method stub

	}

}
