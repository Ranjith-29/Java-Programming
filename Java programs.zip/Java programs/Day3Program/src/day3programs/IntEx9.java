package day3programs;

import java.util.Scanner;

public class IntEx9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		double tempf;
		double tempc;
		System.out.println("Enter the temperature in fahrenheit");// TODO Auto-generated method stub
        tempf = sc.nextDouble(); 
        tempc = ((tempf)-32)*5/9;
        System.out.println("Temperature in Celsius : "+tempc);
        
	}

}
