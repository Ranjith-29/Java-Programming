package daytwo;

import java.util.Scanner;

public class IntEx6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Player team");
		String pname = sc.nextLine();
		System.out.println("Enter the Country Name");
		String cname = sc.nextLine();
		System.out.println("Enter the Country Name");
		String cname1 = sc.nextLine();
		int mat,inns,no,runs,hs,hun,fif,zer,syear,eyear;
		int mat1,inns1,no1,runs1,hs1,hun1,fif1,zer1,syear1,eyear1;
		Float avg1,avg2;
		System.out.println("Enter the no of Started Year");
		syear = sc.nextInt();
		System.out.println("Enter the no of Ended Year");
		eyear = sc.nextInt();
		System.out.println("Enter the no of Matches");
		mat = sc.nextInt();
		System.out.println("Enter the no of Inns");
		inns = sc.nextInt();
		System.out.println("Enter the no of Notout");
		no = sc.nextInt();
		System.out.println("Enter the no of Runs");
		runs = sc.nextInt();
		System.out.println("Enter the no of Highlights");
		hs = sc.nextInt();
		System.out.println("Enter the no of Average");
		avg1 = sc.nextFloat();
		System.out.println("Enter the no of Hundreds");
		hun = sc.nextInt();
		System.out.println("Enter the no of Fifties");
		fif = sc.nextInt();
		System.out.println("Enter the no of Zeros");
	    zer = sc.nextInt();
	    System.out.println("Enter the no of Started Year");
		syear1 = sc.nextInt();
		System.out.println("Enter the no of Ended Year");
		eyear1 = sc.nextInt();
		System.out.println("Enter the no of Matches");
		mat1 = sc.nextInt();
		System.out.println("Enter the no of Inns");
		inns1 = sc.nextInt();
		System.out.println("Enter the no of Notout");
		no1 = sc.nextInt();
		System.out.println("Enter the no of Runs");
		runs1 = sc.nextInt();
		System.out.println("Enter the no of Highlights");
		hs1 = sc.nextInt();
		System.out.println("Enter the no of Average");
		avg2 = sc.nextFloat();
		System.out.println("Enter the no of Hundreds");
		hun1 = sc.nextInt();
		System.out.println("Enter the no of Fifties");
		fif1 = sc.nextInt();
		System.out.println("Enter the no of Zeros");
	    zer1 = sc.nextInt();
	    System.out.println("--------------"+pname+"-------------------");
	    System.out.println("Carrier statistics");
	    System.out.println("country name"+"\t"+ "SYear"+"\t"+ "EndYear"+"\t"  +  "Mat"+"\t" + "inns"+"\t" + "No"+"\t" + "Runs"+"\t" + "Hs"+"\t" + "Avg"+"\t" + "100s"+"\t" + "50s"+"\t" + "0s");  
	    System.out.println(cname+"\t" + syear+"\t"  + eyear+"\t"  +  mat+"\t" + inns+"\t" + no+"\t" + runs+"\t" + hs+"\t" + avg1+"\t" + hun+"\t"+ fif+"\t" +zer);      
	    System.out.println(cname1+"\t" + syear1+"\t"  + eyear1+"\t"  +  mat1+"\t" + inns1+"\t" + no1+"\t" + runs1+"\t" + hs1+"\t" + avg2+"\t" + hun1+"\t"+ fif1+"\t" +zer1);      
	}
     
}
