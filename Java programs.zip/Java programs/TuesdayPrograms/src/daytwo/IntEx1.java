package daytwo;

public class IntEx1 {

	public static void main(String[] args) {
		int x = 10;
		System.out.println(x);
		System.out.println("x");
		System.out.println("x:" +x);
		System.out.println("the value of x is: " +x);

	}

}
