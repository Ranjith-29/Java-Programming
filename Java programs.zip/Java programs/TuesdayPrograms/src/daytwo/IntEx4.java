package daytwo;

import java.util.Scanner;

public class IntEx4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		float height;
		int year;
		height = scanner.nextFloat();
		year = scanner.nextInt();
		System.out.println("Year : My Height");
		System.out.println(".........");
		System.out.println(year+ " : " +height);

	}

}
