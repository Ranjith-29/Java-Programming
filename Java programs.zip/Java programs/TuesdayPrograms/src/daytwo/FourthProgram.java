package daytwo;

public class FourthProgram {

	public static void main(String[] args) {
		System.out.println("My name is : Ranjith");
		System.out.println("My Best friend's name: Bala");
		System.out.println("my favorite color is : Yellow");
		System.out.println("My Favorite car is Range Rover");
		System.out.println("My Favorite sport is : Cricket");
		System.out.println("My Hobbies are : Creating Video on Utube, Insta");

	}

}