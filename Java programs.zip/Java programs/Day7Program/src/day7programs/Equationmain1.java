package day7programs;

public class Equationmain1 {

	public static void main(String[] args) {
		Equation1 eq = new Equation1(5,10,15);
		eq.solution();
		System.out.println("Total sum of equation in return type is : "+eq.equationValue()); // TODO Auto-generated method stub

	}

}
