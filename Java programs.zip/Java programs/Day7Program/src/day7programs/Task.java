package day7programs;

public class Task {
	float a,b,c,m,d;
	void var(float a1,float b1,float c1,float d1){
		a = a1;
		b = b1;
		c = c1;
		d = d1;
	}
	float equationValue(){
		m = (3*a*+9*b)-(4*c+2*d);
		return m;
	}
}
  

