package day7programs;

public class Taskmain1 {

	public static void main(String[] args) {
		Task1 eq = new Task1(5,10,15,20);
		eq.solution();
		System.out.println("Total sum of equation in return type is : "+eq.equationValue()); // TODO Auto-generated method stub


	}

}
