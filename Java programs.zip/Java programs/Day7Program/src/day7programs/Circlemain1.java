package day7programs;

public class Circlemain1 {

	public static void main(String[] args) {
		Circle1 eq = new Circle1(3.56);
		Circle1 eq1 = new Circle1(12.22);
		Circle1 eq2 = new Circle1(23.456);
		eq.solution();
		eq.solution1();
		eq1.solution();
		eq1.solution1();
		eq2.solution();
		eq2.solution1();
		System.out.println("===========================================================");
		System.out.println("Total sum of equation in return type is: "+"Area of Circle: "+eq.equationValue());
		System.out.println("Total sum of equation in return type is: "+"Circumference of Circle : "+eq.equationValue1());
		System.out.println("Total sum of equation in return type is: "+"Area of Circle : "+eq1.equationValue());
		System.out.println("Total sum of equation in return type is: "+"Circumference of Circle: "+eq1.equationValue1());
		System.out.println("Total sum of equation in return type is: "+"Area of Circle : "+eq2.equationValue());
		System.out.println("Total sum of equation in return type is: "+"Circumference of Circle: "+eq2.equationValue1());
	}

}
