package day7programs;

public class Circle {
	double radius;
	double Area;
	double circumference;
    void var(double r) {
    	radius = r;
	}
    double equationValue(){
		Area = 3.14*radius*radius;
		return Area;
	}
    double equationValue1(){
		circumference = 2*3.14*radius;
		return circumference;
	}

}
