package day7programs;

public class Program {
	double width;
	double height;
	double depth;
	double volume;
	void var(double w1,double h1,double d1){
		width = w1;
		height = h1;
		depth = d1;
	}
	double equationValue(){
		volume = width*height*depth;
		return volume;
	}

}
