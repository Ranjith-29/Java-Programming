package day7programs;

public class Square {
	float side; 
	float area;
	float perimeter;
	
	void sideInit(float side1){  //eq.side = 20; //eq.sideIntit(20); 
		side = side1;
		
	}
	void squareArea() {
		 area = side * side;
		 System.out.println("Area of Square is: "+area);
		}
	float squarePerimeter() {
		 perimeter = 4 * side;
		 return perimeter;
		 
	}

}
