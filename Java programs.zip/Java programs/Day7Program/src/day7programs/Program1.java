package day7programs;

public class Program1 {
	double width;
	double height;
	double depth;
	double volume;
	double volume1;
	Program1(double w1,double h1,double d1){
		width = w1;
		height = h1;
		depth = d1;
	}
	void solution() {
		volume = width*height*depth;
		 System.out.println("Total sum of equation in void type is : "+volume);
		
	}
	double equationValue(){
		volume1 = width*height*depth;
		return volume1;
	}

}
