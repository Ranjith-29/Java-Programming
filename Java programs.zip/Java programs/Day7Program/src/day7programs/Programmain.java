package day7programs;

public class Programmain {

	public static void main(String[] args) {
		Program eq = new Program();
		eq.var(5,10,15);
		System.out.println("Volume of the cube is : "+eq.equationValue());

	}

}
