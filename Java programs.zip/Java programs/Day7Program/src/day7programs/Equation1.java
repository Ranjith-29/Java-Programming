package day7programs;

public class Equation1 {
	float a,b,c,m;
	float sum;
	Equation1(float a1,float b1,float c1)  //parameterized Constructor
	{
		a = a1;
		b = b1;
		c = c1;
	} 
	void solution() {
		sum = (3*a)+(5*b)-c;
		 System.out.println("Total sum of equation in void type is : "+sum);
		
	}
	float equationValue(){
		m = (3*a)+(5*b)-c;
		return m;
	}

}
//Parameterizing Constructor + Return function + void function
