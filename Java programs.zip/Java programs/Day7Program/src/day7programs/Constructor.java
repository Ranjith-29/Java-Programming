package day7programs;

public class Constructor {
	float side; 
	float area;
	float perimeter;
	Constructor(float side1)  //parameterized Constructor
	{
		side = side1;
	} 
/*	Constructor(){ //Constructor
		side = 10;
	} */
	
	//void sideInit(float side1){
	//	side = side1;
		
	//}
	void squareArea() {
		 area = side * side;
		 System.out.println("Area of Square is: "+area);
		}
	float squarePerimeter() {
		 perimeter = 4 * side;
		 return perimeter;
		 
	}

}

