package day18programs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class BRRead {
	public static void main(String[] args) throws IOException{
		char char1;
		BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter data in Characters, 'q' to quit");
		do {
			char1 = (char)bufferedreader.read();
			System.out.println(char1);
		}while(char1 != 'q');
		BufferedReader breadString = new BufferedReader(new InputStreamReader(System.in));
		String str;
		System.out.println("Enter text and 'stop' to quit");
		do {
			str = breadString.readLine(); //readLine() is used to read a String
			System.out.println(str);
		}while(!str.equals("stop"));
	}

}
