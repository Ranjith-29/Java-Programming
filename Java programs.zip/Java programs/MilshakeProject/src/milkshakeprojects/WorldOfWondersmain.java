package milkshakeprojects;
import java.util.Scanner;
public class WorldOfWondersmain {

	public static void main(String[] args) {
		WorldOfWonders wow = new WorldOfWonders();
		wow.WorldOfWondersMenu();
		System.out.println("\nNow your Cart has : ");
		for(int i=0;i<wow.array.size();i++) {
			System.out.println("--> "+wow.array.get(i));
		}
		System.out.println("Total price is : "+wow.price);	
	}
}
/*		int num;
		Scanner sc = new Scanner(System.in);
		WorldOfWonders wow = new WorldOfWonders();
		wow.Welcome();
		wow.display();
		System.out.println("Enter Your Option for Adding to the Cart");
    	num = sc.nextInt();		
		while(true);
	} 

} */
