package sba3taxi;

import java.util.Scanner;

public class cabPayment {
	public static final String ANSI_RESET="\u001B[0m";
	public static final String ANSI_BLACK2="\u001B[40m";
	public static final String ANSI_YELLOW2 = "\u001B[43m";
	public static final String ANSI_WHITE="\u001B[37m";
	 public  void Payment() {
	    	Scanner sc = new Scanner(System.in);
	    	System.out.println("Here you go,Payment methods/Options");
	    	int pay = sc.nextInt();
	    	System.out.println(ANSI_YELLOW2+"Choose any one of the option from this"+ANSI_RESET);
	    	System.out.println(" 1.cash\n 2.phonepay\n 3.GooglePay\n 4.paytm");
	    	int Option =sc.nextInt();
	    	try {
	    		switch(Option) {
	    		case 1 :
	    			System.out.println(ANSI_BLACK2+ANSI_WHITE+"AMOUNT SUCCESSFULLY PAID VIA CASH"+ANSI_RESET);
	    			break;
	    		case 2 :
	    			System.out.println(ANSI_BLACK2+ANSI_WHITE+"AMOUNT SUCCESSFULLY TRANSFERRED VIA PHONEPAY"+ANSI_RESET);
	    			break;
	    		case 3 :
	    			System.out.println(ANSI_BLACK2+ANSI_WHITE+"AMOUNT SUCCESSFULLY TRANSFERRED VIA GOOGLE PAY"+ANSI_RESET);
	    			break;
	    		case 4 :
	    			System.out.println(ANSI_BLACK2+ANSI_WHITE+"AMOUNT SUCCESSFULLY TRANSFERRED VIA PAYTM"+ANSI_RESET);
	    			break;
	    			default : throw new Exception();
	    				
	    		   }
	    	}catch(Exception ae) {
	    		System.out.println("Invalid details, try again"+ae);
	    	}

}
}
