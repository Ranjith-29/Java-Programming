package sba3taxi;

import java.util.regex.Pattern;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.ArrayList;
import sba3taxi.User;
public class TaxiMain {
	public static final String ANSI_RESET="\u001B[0m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_CYAN="\u001B[36m";
	public static final String ANSI_CYAN2="\u001B[46m";
	public static final String ANSI_RED="\u001B[31m";
	public static final String ANSI_RED2="\u001B[41m";
	public static final String ANSI_PURPLE="\u001B[35m";
	public static final String ANSI_PURPLE2="\u001B[45m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_YELLOW2 = "\u001B[43m";
	public static final String ANSI_BLUE= "\u001B[44m";
	public static final String ANSI_WHITE="\u001B[37m";
	public static final String ANSI_BLACK="\u001B[30m";
	public static final String ANSI_BLACK2="\u001B[40m";
	static ArrayList<User> users = new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		StringBuilder stringbuilder = new StringBuilder(ANSI_BLACK2+ANSI_WHITE+"* WELCOME TO SINGARA CHENNAI  *"+ANSI_RESET);
  		int choice;
     	do {
		System.out.println(ANSI_BLACK2+ANSI_WHITE+"|==========================|"+ANSI_RESET);
		System.out.println(ANSI_YELLOW2+"|*WELCOME TO MAJAA TRAVELS*|"+ANSI_RESET);
		System.out.println(ANSI_BLACK2+ANSI_WHITE+"|==========================|"+ANSI_RESET);
		System.out.println(ANSI_BLUE+ANSI_WHITE+"--------------------------------------------------------------"+ANSI_RESET);
		System.out.println(ANSI_GREEN+"1. REGISTER \n2. LOG IN"+ANSI_RESET);
		System.out.println(ANSI_BLUE+ANSI_WHITE+"--------------------------------------------------------------"+ANSI_RESET);
		System.out.print("Enter your choice: ");
		//System.out.println(stringbuilder);
		choice = scanner.nextInt();
		try {
		switch (choice) {
		case 1:
		System.out.print("Enter your name: ");	
		String name = scanner.next();
		System.out.print("Enter your Userid: ");
		String username = scanner.next();
		System.out.print("Enter your Mobile Number: ");
		String mobnumber = scanner.next();
		System.out.print("Enter your Email: ");
		String useremail = scanner.next();
		System.out.print("Enter your Password: ");
		String userpassword = scanner.next();  
		User user = new User(name,username,mobnumber,useremail,userpassword);
		users.add(user);
		System.out.println(ANSI_GREEN+"Account Created successfully"+ANSI_RESET);
		break;
		case 2:
			System.out.print("Enter your User Id: ");
			String userName = scanner.next();
			System.out.print("Enter your Password: ");
			String userPassword = scanner.next();
			boolean isUserFound = false;
			for (User u : users) {
		    if (u.getUsername().equals(userName) && u.getUserpassword().equals(userPassword)) {
			System.out.println(ANSI_YELLOW2+ANSI_WHITE+"Login successful"+ANSI_RESET);	
			isUserFound = true;
			break;
			}

		}
			if (!isUserFound) {
			System.out.println(ANSI_RED2+ANSI_WHITE+"Invalid email or password"+ANSI_RESET);
			System.out.println("Do you want to recover your account? (Y/N) ");
			String ans=scanner.next();
			if(ans.equals("Y")) {
			System.out.println("please enter your email Address: ");
			String userEmail1=scanner.next();
			User.recoverAccount(userEmail1);
			}

		}
			break;
			
			case 3:
			if (users.size() == 0) {
			System.err.println("Please Create Account..!");
			System.out.println("-----------------------------------------------");
	    	break;
			}
			default : throw new Exception();
		}
	  }catch(Exception ae) {
		  System.err.println("Something Went Wrong & Click the Valid Option 1 or 2 "+ae);
		  System.out.println("-----------------------------------------------");
	  }
	}
    while(choice!=2); 
	
	
		
		      cabDetail cabdetail=new cabDetail();
		      cabLogin cablogin = new cabLogin();
			  cabPayment cabpayment = new cabPayment();
			//  cabUser cabuser = new cabUser("ranjithrj@gmail.com","rj@29");
			  int totalFare=0;
			  int rate=0;
	    /*  
			Scanner scanner = new Scanner(System.in);
			System.out.println("-----------------------------------------------");
			System.out.println("Login your account");
			System.out.println("----------------------------------------------");
			System.out.print("Enter email ID : ");
		    String email1 = scanner.nextLine();
		    System.out.println("----------------------------------------------");
		    System.out.print("Enter  password : ");
		    String password1=scanner.nextLine();
		    String email2 = cabuser.getemail();
		    String password2=cabuser.getpassword();
		  
		   	if(email2.equals(email1) && password2.equals(password1)) {
		   	     System.out.println("Hare Bai !Login successful,Welcome to Sundara Cab Travels :)");
		   	}else {
		   		System.out.println("Oops :( Login failed,continue with your registered mobile number");
		   		System.out.println("Enter your mobile number");
		   		cablogin.createAccount();
		   		System.out.println("Hurrayy!you logged in");
		   	} /*  int totalFare=0;
			    int rate=0;
			    cabPayment cabpayment = new cabPayment();
			    cabLogin cablogin = new cabLogin();
		        cabDetail cabdetail=new cabDetail(); */
			    System.out.println("Haree Boi,Ranjith You Logged in Successfull");
		        System.out.println(ANSI_BLACK2+ANSI_YELLOW+"*******************************"+ANSI_RESET);
		        System.out.println(stringbuilder);
		   	    System.out.println(ANSI_BLACK2+ANSI_YELLOW+"*******************************"+ANSI_RESET);
		   	    //cabdetail.bookCab();
				System.out.println(ANSI_GREEN+"Pick your location and have a safe ride with us!"+ANSI_RESET);
				System.out.println("************************************************");
				//predefined locations
				ArrayList<String> places=new ArrayList<String>();
				places.add("Egmore");
				places.add("Tambaram");
				places.add("Keelpaakam");
				places.add("OMR");
				places.add("Mamallapuram");
				places.add("Marina Beach");
				System.out.println("These are the current locations where cab is availabe : "+places);		
				int baseFare = 10;
				System.out.println("Select the source location");
				System.out.println("printLocations :"+places);
				String source=scanner.next();
				System.out.println("select the destination location");
				System.out.println("printLocations : "+places);
				String destination=scanner.next();		
				if(source.equals("Egmore") && destination.equals("Tambaram") || (source.equals("Tambaram") && destination.equals("Egmore"))){
					rate = 35;
					totalFare +=rate;
				}else if(source.equals("Tambaram") && destination.equals("Keelpaakam")|| (source.equals("Keelpaakam") && destination.equals("Tambaram"))) {
					rate = 50;
					totalFare +=rate;
				}else if(source.equals("Keelpaakam") && destination.equals("OMR")|| (source.equals("OMR") && destination.equals("Tambaram"))) {
					rate = 100;
					totalFare +=rate;
				}else if(source.equals("OMR") && destination.equals("Mamallapuram")|| (source.equals("Mamallapuram") && destination.equals("OMR"))) {
					rate = 87;
					totalFare +=rate;
				}else if(source.equals("Mamallapuram") && destination.equals("Marina Beach")|| (source.equals("Marina Beach") && destination.equals("Mamallapuram"))) {
					rate = 150;
					totalFare +=rate;
				}
				else {
					System.out.println("we are not coming that location right now " + source + " to " + destination + " is $" + rate);
				}	
				//cabdetail.bookCab();
				System.out.println("want to cancel cab(yes/no)");
				String makeSelection = scanner.next();
				if (makeSelection.equals("yes")) {
					cablogin.userCancel();
				}
			    
				System.out.println("Do you want to fix the location(Yes/no)");
				String select = scanner.next();
				if(select.equals("yes")) {	
				cabdetail.bookCab();
				System.out.println(ANSI_BLACK2+ANSI_WHITE+"*********CAB DETAILS*******"+ANSI_RESET);
				System.out.print("Driver Name: Suresh"+"\nCab Number: Tn45A7653"+"\nCab Name: Innova");
				System.out.println("\n====================================================================");
				System.out.println(ANSI_GREEN+"\nYour Journey Started......! Have a Safe and Enjoyable Jorney"+ANSI_RESET);
				if(rate > 0)	{
				    System.out.println("Do you wanna give tip?(yes/no)");
				    String check=scanner.next();
				    System.out.println("Enter tip in percenatge");
				    int tipPercentage = scanner.nextInt();
					int tip = (rate * tipPercentage)/100;
					totalFare = rate + tip;
				System.out.println("The fare for your journey from " + source + " to " + destination + " and baseFare is "+ baseFare+ "  total to pay is $" + rate);     
				System.out.println(ANSI_CYAN+"TOTAL AMOUNT TO BE PAID :"+totalFare+ANSI_RESET);
				cabpayment.Payment();
				System.out.println(ANSI_PURPLE2+"THANKS FOR CHOOSING OUR MOKKA TRAVELS CAB_.._"+ANSI_RESET);									
				return;				
				}
				else {
					
			           System.out.println("You Decided to change Location");
				}
				System.out.println("Change Destination will Applicable Extra Charges:(Yes/no)");
				String confirm = scanner.next().toLowerCase();
				if(confirm == "yes") {
				int extraCharge = 20;
				System.out.println("Enter new destination");
				String newdestination =scanner.next();
				for(String location :  places) {
					String regex = "\\b" + location + "\\b";
				Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE);
				Matcher matcher = pattern.matcher(newdestination);
				if(matcher.find()) {
					System.out.println(ANSI_RED2+ANSI_WHITE+"Your destination is Changed"+ANSI_RESET);
					System.out.println("=========================================================");
					System.out.println(ANSI_BLUE+"Hey Great..!You Have Reached Your destination & Extra Charge is Applied for Changing The Destination in Midway"+ANSI_RESET);
					System.out.println("=========================================================");
					System.out.println("Your fare is $" + totalFare + "(extra charge: $" + extraCharge + ")");			
					if(rate > 0)	{
				    System.out.println("Do you wanna give tip?(yes/no)");
				    String check=scanner.next();
				    System.out.println("Enter tip in percenatge");
				    int tipPercentage = scanner.nextInt();
					int tip = (rate * tipPercentage)/100;
					totalFare = rate +  extraCharge + tip;
					System.out.println("------------------------------------------------------------------------------------------------------  ");
					System.out.println("The fare for your journey from " + source + " to " + destination +  "with " + extraCharge + "and"  + tip + "is  $" + totalFare );
					System.out.println("---------------------------------------------------------------------------------------------------------");
					System.out.println(ANSI_CYAN+"TOTAL AMOUNT TO BE PAID :"+totalFare+ANSI_RESET);
					cabpayment.Payment();
					System.out.println("-----------------------------------------------------------------------------");
					System.out.println(ANSI_PURPLE2+ANSI_WHITE+"THANKS FOR CHOOSING OUR MAJAA TRAVELS CAB_.._"+ANSI_RESET);
					return;				
				}
					System.out.println("Your location doesnt match with our predefine locations");
				}
				}
				}
				else if(confirm == "no") {
					int tipPercentage = scanner.nextInt();
					int tip = (rate * tipPercentage)/100;
					totalFare = rate + tip;
					System.out.println("------------------------------------------------------------------------------------------------------  ");
					System.out.println("The fare for your journey from " + source + " to " + destination +  "with "  + tip + "is  $" + totalFare );
					System.out.println("---------------------------------------------------------------------------------------------------------");
					System.out.println(ANSI_CYAN+"TOTAL AMOUNT TO BE PAID :"+totalFare+ANSI_RESET);
					cabpayment.Payment();
					System.out.println("-----------------------------------------------------------------------------");
					System.out.println(ANSI_PURPLE2+ANSI_WHITE+"THANKS FOR CHOOSING OUR MAJAA TRAVELS CAB_.._"+ANSI_RESET);
					return;
				}
		}
	

}
}
	
	
	


