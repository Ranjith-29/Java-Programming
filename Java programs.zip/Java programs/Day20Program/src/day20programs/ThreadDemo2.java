package day20programs;

public class ThreadDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new NewThread();
		try {
			for(int ctr=5;ctr>0;ctr--) {
				System.out.println("Main Thread: "+ctr);
				Thread.sleep(5000);
			}
		}catch(InterruptedException e) {
			e.printStackTrace();
	}System.out.println("Main Thread Exits");

	}

}
