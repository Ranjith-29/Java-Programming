package day20programs;
//Creating a Thread /New Thread
public class NewThread implements Runnable {
	Thread thread;
	NewThread(){//Constructor
		thread = new Thread(this, "Child-Thread");
		System.out.println("Child Thread: "+ thread);
		thread.start();
	}
	public void run() {
		try {
			for(int ctr = 5; ctr>0; ctr--) {
				System.out.println("Child Thread: "+ctr);
				//System.out.println("Child Thread: "+ name +" : " +ctr);
				Thread.sleep(2000);
			}
		}catch(InterruptedException e) {
				e.printStackTrace();
		}System.out.println("exiting Child Thread");
	}

}
