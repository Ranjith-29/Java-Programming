package day20programs;

public class CurrentThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread mainThread = Thread.currentThread();
		System.out.println("Main Thread: "+mainThread);
		mainThread.setName("ThreadMain-2023");
		System.out.println("Main Thread: "+mainThread);
		for(int ctr = 10; ctr>0; ctr--) {
			System.out.println(ctr);
			try {
				Thread.sleep(5000);
			}catch(InterruptedException e) {
				e.printStackTrace();
			}//milli seconds
		} System.out.println("End");

	}

}
