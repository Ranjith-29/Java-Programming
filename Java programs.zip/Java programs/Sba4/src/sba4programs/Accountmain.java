package sba4programs;
//import static sba4programs.User.deposit;
//import static sba4programs.User.withdraw;
//import  static sba4programs.CreateAccount.Operations;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileNotFoundException;
//import java.util.InputMismatchException;
import java.util.Scanner;

public class Accountmain {
	public static final String ANSI_RESET="\u001B[0m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_GREEN2 = "\u001B[42m";
	public static final String ANSI_CYAN="\u001B[36m";
	public static final String ANSI_CYAN2="\u001B[46m";
	public static final String ANSI_RED="\u001B[31m";
	public static final String ANSI_RED2="\u001B[41m";
	public static final String ANSI_PURPLE="\u001B[35m";
	public static final String ANSI_PURPLE2="\u001B[45m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_YELLOW2 = "\u001B[43m";
	public static final String ANSI_BLUE= "\u001B[44m";
	public static final String ANSI_WHITE="\u001B[37m";
	public static final String ANSI_WHITE2="\u001B[47m";
	public static final String ANSI_BLACK="\u001B[30m";
	public static final String ANSI_BLACK2="\u001B[40m";
	
	
	public static ArrayList<String> transactionHistory = new ArrayList<String>();
	public static void main(String[] args)
	{
		User[] userArray = new User[3];
		userArray[0]=new User("ranjith1@upi","Ranjith","9876543210",87654,"savings",200000.00);
		userArray[1]=new User("hari2@upi","Hariharan","8976543219",98763,"current",200000.00);
		userArray[2]=new User("ram23@upi","Ram","7896543210",98765,"savings",2000000.00);
		double balance= 200000;
		Scanner scanner=new Scanner(System.in);
		double Totalbalance;
		CreateAccount ca = new CreateAccount();
		ca.Welcome();	
	
		System.out.println("---------------------------");
				 System.out.println("Enter mobile number:");
				 String mobileNumber= scanner.next();
     			 User matchingCustomer = null;
				 for(int i=0; i< userArray.length;i++) {
					 User user = userArray[i];
					   if(user.getMobileNumber().equals(mobileNumber)) {
						   matchingCustomer = user;
							 System.out.println(ANSI_CYAN2+ANSI_BLACK+"Your Mobile Number Valid....!"+ANSI_RESET);
							 break;
						  }
					 }
				  if (matchingCustomer != null) { 
					 Scanner scannner = new Scanner(System.in);
					 while(true) {
						 ca.Operations();
						 int choice = scanner.nextInt();
						 switch(choice) {
							case 1:
							
								ca.withdraw(choice);
								
					            break;
					            
							case 2:
						
								double amount2=0;
								ca.deposit(amount2);
								
								
								break;
								
							case 3:
								
								System.out.println("Check Your Current Balance: ");
								ca.viewbalance();
								
								break;
						  case 4:
							       System.out.println("Enter Your Account Number");
							       int Acc = scanner.nextInt();
							       if(Acc == userArray[0].Acc_num) {
							       System.out.println("Holder's UPI ID  " +userArray[0].upiId);
								   System.out.println("Holder's Name: "+userArray[0].Name);
								   System.out.println("Holder's Mobnum: "+userArray[0].mobileNumber);
								   System.out.println("Holder's Account Number: "+userArray[0].Acc_num);
								   System.out.println("Account type: "+userArray[0].Acc_type);
								   System.out.println("Holder's Balance");
								   ca.viewbalance();
								   ca.Operations();
							       }
							       else if (Acc == userArray[1].Acc_num) {
								       System.out.println("Holder's UPI ID  " +userArray[1].upiId);
									   System.out.println("Holder's Name: "+userArray[1].Name);
									   System.out.println("Holder's Mobnum: "+userArray[1].mobileNumber);
									   System.out.println("Holder's Account Number: "+userArray[1].Acc_num);
									   System.out.println("Account type: "+userArray[1].Acc_type);
									   System.out.println("Holder's Balance");
									   ca.viewbalance();
									   ca.Operations();
								       }
							       else if (Acc == userArray[2].Acc_num) {
								       System.out.println("Holder's UPI ID  " +userArray[2].upiId);
									   System.out.println("Holder's Name: "+userArray[2].Name);
									   System.out.println("Holder's Mobnum: "+userArray[2].mobileNumber);
									   System.out.println("Holder's Account Number: "+userArray[2].Acc_num);
									   System.out.println("Account type: "+userArray[2].Acc_type);
									   System.out.println("Holder's Balance");
									   ca.viewbalance();
									   ca.Operations();
								       }
								   break;
						  case 5 :
							  ca.transfer(choice);
							  break;
							  
							       
						  case 6:
							  System.out.println("\nPlease  rate your experience by giving Stars(1-5):");
								int rating = scanner.nextInt();
								if(rating <= 3) {
									System.out.println("We'll try to resolve your Uncomforts Zone, if its Possible ,Thanks for Spending Your Valuable Time By giving Your Feedback");
									try {
										BufferedWriter writer = new BufferedWriter(new FileWriter("rating.txt"));
										writer.write("Rating: "+rating);
										writer.newLine();
										writer.close();
										System.out.println("Thanks for your Rating..!"+"\n Have a Great Day");				
										ca.Operations();
									}catch(IOException e) {
										System.out.println("Error in writing Rating file"); 
									}
								}else {
									System.out.println("Happy to hear your feedback"+"\nThanks for Spending Your Valuable Time By giving Your Feedback"+"\nVisit our bank again!");
									try {
										BufferedWriter writer = new BufferedWriter(new FileWriter("rating.txt"));
										writer.write("Rating: "+rating);
										writer.newLine();
										writer.close();
										System.out.println(ANSI_RED2+ANSI_BLACK+"Thanks for your Rating..!"+"\n Have a Great Day"+ANSI_RESET);				
										ca.Operations();
									}catch(IOException e) {
										System.out.println("Error in writing Rating file"); 
									}
					
								}
								break;
						  case 7:
								System.out.println("Do you have any feedback or complaints?(Yes/No)");
								String answer= scanner.next();				
								if(answer.equalsIgnoreCase("Yes")) {
									System.out.println("Chill..! We Will Try to Wrok with Your Comfortable");
									
									//Write a feedback to a file
									try {
										BufferedWriter writer = new BufferedWriter(new FileWriter("rating.txt"));
										//writer.write("Feedback: "+feedback);
										writer.newLine();
										writer.close();
										System.out.println("Thanks for your feedback...!"+"\n Have a Great Day");				
										ca.Operations();
									}catch(IOException e) {
										System.out.println("Error in writing feedback file"); 
									}
									}else {
										System.out.println(ANSI_GREEN2+ANSI_BLACK+"Thanks for Spending Your Valuable Time use"+ANSI_RESET);
										
									}
								break;
						  case 8:
							   System.out.println(ANSI_BLACK2+ANSI_WHITE+"Current Transaction History: "+ANSI_RESET);
							    FileInputStream fin = null;
							    int track;
							    try {
							    	fin = new FileInputStream("transaction_statement.txt"); 	
							    }catch (FileNotFoundException e) {
							    	System.out.println("File Not Found");
							    	
							    }
							    try {
							    	do {
							    		track = fin.read();
							    		System.out.print((char)track);
							    	}while(track != -1);
							    }catch(IOException e) {
							    	System.out.println("Cannot Read file");
							    }
							    System.out.println("\n");
						        //ca.Operations();
                                break;
								
							  
						  default : 
								   System.out.println(ANSI_GREEN2+ANSI_BLACK+"Thank You Visit Again...!"+"Welcome"+ANSI_RESET);
									//ca.Operations();
									System.exit(0);
						            	 
							 
			               		
				          }	
					   }
				  }			  	 				      
				
	}
}

