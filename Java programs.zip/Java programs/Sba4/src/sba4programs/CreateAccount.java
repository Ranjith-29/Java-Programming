package sba4programs;
import sba4programs.User;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class CreateAccount implements Iface {
	public static final String ANSI_RESET="\u001B[0m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_GREEN2 = "\u001B[42m";
	public static final String ANSI_CYAN="\u001B[36m";
	public static final String ANSI_CYAN2="\u001B[46m";
	public static final String ANSI_RED="\u001B[31m";
	public static final String ANSI_RED2="\u001B[41m";
	public static final String ANSI_PURPLE="\u001B[35m";
	public static final String ANSI_PURPLE2="\u001B[45m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_YELLOW2 = "\u001B[43m";
	public static final String ANSI_BLUE= "\u001B[44m";
	public static final String ANSI_WHITE="\u001B[37m";
	public static final String ANSI_WHITE2="\u001B[47m";
	public static final String ANSI_BLACK="\u001B[30m";
	public static final String ANSI_BLACK2="\u001B[40m";
	
	
	
	public static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("0.0");
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
	public static final Random random = new Random();
	public static String otp = "";
	public final double depositLimit = 40000;
	public final double withdrawLimit = 60000;
	//public static final double balance = 300000;
	public static final Scanner scanner = new Scanner(System.in);
	double Totalbalance = 200000;
	
	Scanner sc = new Scanner(System.in);
	
	
	@Override
	public void Welcome() {
		System.out.println(ANSI_PURPLE+"Hey , You Chosen Great Kerigalan Magic Hi-fi Service Bank"+ANSI_RESET);
	}
	public  void withdraw(double amount) {
		generateOTP();
		System.out.println(ANSI_BLACK2+ANSI_WHITE+"Please enter the OTP sent to your phone: " +otp+ANSI_RESET);
		String inputOTP = scanner.nextLine();
		if(inputOTP.equals(otp)) {
			System.err.println(ANSI_YELLOW2+ANSI_BLACK+"Verified OTP....! "+" You Can Proceed with Next"+ANSI_RESET);
			System.out.println("Enter withdraw amount");
			double amount1 = scanner.nextDouble();
			if (amount1 <= withdrawLimit) {
				Totalbalance = Totalbalance-amount1 ;
				System.err.println("Sending Mobile Notification");
				System.out.println(ANSI_GREEN2+ANSI_BLACK+"Dear User, You Succesfully Withdrawal Your Amount"+"\nYour balance now is ₹ "+Totalbalance+ANSI_RESET);
			}

			else if (amount1 <= 0) {
				System.out.println("Withdrwal Amount Must Be > ₹ 0/-");
				System.exit(0);
			} else if (amount1 > Totalbalance) {
				System.out.println(ANSI_YELLOW2+"Insufficient Balance."+ANSI_RESET);
				System.exit(0);
			} else {

				System.err.println("Limitation for Withdraw Amount"+"\nCan't Make Transactions less than ₹200 & More than ₹40000/-");
				System.exit(0);
			}

			Date date = new Date();
			String transaction = DATE_FORMAT.format(date) + "- Type : Withdrawal Amount ₹ " +amount1 + "Available balance in Your Account₹ "
					+ Totalbalance;
			System.out.println(transaction);
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter("transaction_statement.txt"));
				writer.write(transaction);
				writer.close();
				System.err.println("Transaction statement downloaded to transaction_statement.txt.");

			} catch (IOException e) {
				System.out.println("Error in writing statement in file");
			}

		}
		if (!inputOTP.equals(otp)) {
			System.out.println("Invalid OTP.sorry,your transaction cancelled.");
			return;
		}
	}
	public void transfer(double amt) {
		generateOTP();
		System.out.println(ANSI_BLACK2+ANSI_WHITE+"Please enter the OTP sent to your phone: " + otp+ANSI_RESET);
		String inputOTP = scanner.next();
		if(inputOTP.equals(otp)) {
			System.out.println(ANSI_YELLOW2+ANSI_BLACK+"Verified OTP....! "+" You Can Proceed with Next"+ANSI_RESET);
			System.out.println("Account Number to transfer");
			int acc = scanner.nextInt();
			if(acc == 87654 || acc == 98763 || acc== 98764 ) {
				   
					 System.out.println("Your Account Number Valid!");
					 System.out.println("Enter Transfer amount");
						double amt2 = scanner.nextDouble();
						if (amt2 <= withdrawLimit) {
							Totalbalance -= amt2;
							System.err.println("Sending Mobile Notification");
							System.out.println(ANSI_GREEN2+ANSI_BLACK+"Dear User, You Succesfully Tranferred Amount₹ "+amt2+ " to Entered Account Number"+"\nYour balance now is ₹"+Totalbalance+ANSI_RESET);
						}
						else if (amt2 <= 0) {
							System.out.println("Transfer Amount Must Be > ₹ 0/-");
							System.exit(0);
						} else if (amt2 > Totalbalance) {
							System.out.println(ANSI_YELLOW2+"Insufficient Balance."+ANSI_RESET);
							System.exit(0);
						} else {

							System.err.println("Can't Make Transactions less than ₹200 & More than ₹40000/-");
							System.exit(0);
						}
						
					}
			           else {  
			        	   System.out.println("Entered InValid Account Number & Transaction Cancelled");
			           }
					
					}
		              if (!inputOTP.equals(otp)) {
			                System.out.println("Invalid OTP.sorry,your transaction cancelled.");
			               return ;				
					 
				  }
			
		
	}

	public  void deposit(double amount1) {
		generateOTP();
		System.out.println(ANSI_BLACK2+ANSI_WHITE+"Please enter the OTP sent to your phone: " + otp+ANSI_RESET);
		String inputOTP = scanner.next();
		if(inputOTP.equals(otp)) {
			System.err.println(ANSI_YELLOW2+ANSI_BLACK+"Verified OTP....! "+" You Can Proceed with Next"+ANSI_RESET);
			System.out.println("Enter amount to deposit ");
			double amount2 = scanner.nextDouble();
			if (amount2 <= depositLimit) {
				Totalbalance += amount2;
				System.err.println("Sending Mobile Notification");
				System.out.println(ANSI_BLACK2+ANSI_YELLOW+"Dear User, You Deposited by ₹ "+amount2+"/- " + "And Your Current Balance is ₹ "+Totalbalance+"/-"+ANSI_RESET);

			} else {
				System.err.println("Your fixed amount to deposit per day is 50000");

			}

			Date date = new Date();
			String transaction = DATE_FORMAT.format(date) + " -  Type : Deposit  : "  +amount2 + " Available balance:"
					+ Totalbalance;
			System.out.println(transaction);
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter("transaction_statement.txt"));
				writer.write(transaction);
				writer.close();
				System.out.println("Transaction statement downloaded to transaction_statement.txt.");

			} catch (IOException e) {
				System.out.println("Error in writing statement in file");
			}

		}
		
		if (!inputOTP.equals(otp)) {
			System.out.println("Invalid OTP.sorry,your transaction cancelled.");
			return;
		}
     
	}

	public void viewbalance() {
		System.out.println("Your current balance is ₹" +Totalbalance);

	}

	public static String formatBalance(double balance) {
		return "₹" + DECIMAL_FORMAT.format(balance);
	}

	public static void generateOTP() {

		// generate 5 digit OTP
		otp = String.format("%05d", random.nextInt(99999));
	}
	public void Operations() {
		System.out.println(ANSI_BLACK2+ANSI_WHITE+"|----------------------------------------------------|"+ANSI_RESET);
		System.out.println(ANSI_WHITE2+ANSI_BLACK+"|************Welcome to RMK BANK OF INDIA************|"+ANSI_RESET);
		System.out.println(ANSI_RED2+ANSI_WHITE+"|----------------------------------------------------|"+ANSI_RESET);
	/*	System.out.print("\n1. Withdraw"+"     3. ViewBalance"+"\n\n2. Deposit"+"\n4. Showdeatils"+"       5. Rating"+"\n6. Feedback"+"       5. Exit"); */
		System.out.println("1. Withdraw");
		System.out.println("\n2. Deposit");
		System.out.println("\n3. View Balance");
		System.out.println("\n4. Show Details");
		System.out.println("\n5. Transfer");
		System.out.println("\n6. Rating");
		System.out.println("\n7. Feedback");
		System.out.println("\n8. View Transcation History");
		System.out.println("\n9. Quit");
		System.out.println("\nEnter Your Choice: ");
	}
 
	
}
