package sba4programs;

public class User1 extends User {

	public User1(String upiId, String Name, String mobileNumber, int Acc_num, String Acc_type, double balance) {
		super(upiId, Name, mobileNumber, Acc_num, Acc_type, balance);
		// TODO Auto-generated constructor stub
	}

}
