package sba4programs;

public interface Iface {
	void Welcome();
	void withdraw(double amount);
	void transfer(double amt);

}
