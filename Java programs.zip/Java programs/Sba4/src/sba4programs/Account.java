package sba4programs;

import java.util.Scanner;

public class Account {
		String name,acc_type;
		String phonenumber;
		int Acc_num;
		double Acc_balance;
		Scanner sc = new Scanner(System.in);
	/*	Account(String name, String phonenumber,int Acc_num, String acc_type, double Acc_balance) 
		{
			this.name = name;
			this.phonenumber = phonenumber;
			this.Acc_num = Acc_num;
			this.acc_type = acc_type;
			this.Acc_balance = Acc_balance;
		} */
		


}
