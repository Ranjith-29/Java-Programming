package day5programs;

import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i,n;
		System.out.println("Enter the value of starting Number" );
		i = sc.nextInt();
		System.out.println("Enter the value of Ending Number" );
	    n = sc.nextInt();// TODO Auto-generated method stub
	    while(i <=n) {
	       System.out.println("Enter the value of Even Numbers: "+i);
	       i = i+2;	
	    }
	}
	    
			
}
