package day5programs;

import java.util.Scanner;

public class Multiforloop {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i,n;
		System.out.println("Enter the value of starting Number" );
		i = sc.nextInt();
		System.out.println("Enter the value of Multiplying Number" );
		n = sc.nextInt();
	    for(i = 1;i<=25;i++) {
	    	System.out.println(n+" * "+i+ " ="+n*i );
	    }
	}

}
