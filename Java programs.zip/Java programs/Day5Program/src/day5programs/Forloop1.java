package day5programs;

import java.util.Scanner;

public class Forloop1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i,n;
		System.out.println("Enter the value of starting Number" );
		i = sc.nextInt();
		System.out.println("Enter the value of Ending Number" );
	    n = sc.nextInt();
	    int j = i;
	    for(j = i; ++j < --n;); System.out.println("Enter the value of Midpoint Number "+j );
	    
	    
	}

}
