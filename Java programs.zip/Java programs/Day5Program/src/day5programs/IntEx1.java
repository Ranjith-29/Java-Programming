package day5programs;

public class IntEx1 {

	public static void main(String[] args) {
		for(int i=100; i>0; i--){
			if(i > 5) continue;
			System.out.println("i: " +i);	
		}   
	}

}