package day5programs;

public class square {
	    float side; 
		float area;
		float perimeter;

}
