package day5programs;

import java.util.Scanner;

public class Printingnum1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i,n;
		System.out.println("Enter the value of starting Number" );
		i = sc.nextInt();
		System.out.println("Enter the value of Ending Number" );
	    n = sc.nextInt();
	    do {
	    	System.out.println("Enter the Numbers 1 to 100: "+i);
			i++;
	    }
		while(i <=n);

	}

}