package day5programs;

import java.util.Scanner;

public class ArrayProgram5 {

	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);
		String studentdetails[] = {"Name","RollNo","Class"};
		String studentdetails1[] = new String[studentdetails.length];
		for(int j=0;j<studentdetails.length;j++) {
			System.out.println("Enter the "+studentdetails[j]+" : ");
			studentdetails1[j]= sc.nextLine();
			
		}
		
		String sub[] = {"Tamil","English","Maths","Science","Social","Computer Science"};    
		int mark[] = new int[sub.length];	
		for(int k=0;k<sub.length;k++) {
			System.out.println("Enter the "+sub[k]+" : ");
			mark[k]= sc.nextInt();
		}
		double total = 0,avg;
		for (int i : mark) {
			total = total + i;
		}
		System.out.println("========================================");
		System.out.println("        Dxc School Report                ");
		System.out.println("========================================");
		System.out.println(studentdetails[0]+" : "  + "\t " + studentdetails1[0] + "\t "+studentdetails[1]+ "  :  " + studentdetails1[1] +  "  \t  " +studentdetails[2]+ "  : " +studentdetails1[2]);
		System.out.println("========================================");
		System.out.println(sub[0]+"             :               "+ mark[0]);
		System.out.println("========================================");
		System.out.println(sub[1]+"           :               "+ mark[1]);
		System.out.println("========================================");
		System.out.println(sub[2]+"             :               "+ mark[2]);
		System.out.println("========================================");
		System.out.println(sub[3]+"           :               "+ mark[3]);
		System.out.println("========================================");
		System.out.println(sub[4]+"            :               "+ mark[3]);
		System.out.println("========================================");
		System.out.println(sub[5]+"  :               "+ mark[5]);
		System.out.println("========================================");
		System.out.println("Total             :               "+ total);
		System.out.println("========================================");
		avg = total / 6;
		System.out.println("Average           :               "+ avg + "%");
		System.out.println("========================================");
		if (avg >= 90 && avg <= 100) {
			System.out.println("Grade             :                  A+");
		} else if (avg >= 80 && avg <= 89) {
			System.out.println("Grade             :                   A");
		} else if (avg >= 70 && avg <= 79) {
			System.out.println("Grade             :                  B+");
		} else if (avg >= 60 && avg <= 69) {
			System.out.println("Grade             :                   B");
		} else if (avg >= 60 && avg <= 69) {
			System.out.println("Grade             :                  C+");
		} else if (avg >= 50 && avg <= 59) { 
			System.out.println("Grade             :                   C");
		} else if (avg >= 40 && avg <= 49) {
			System.out.println("Grade             :                   D");
		} else { 
			System.out.println("Grade             :                   E");
		}
		System.out.println("========================================");
	}

}
