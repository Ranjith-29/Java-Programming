package day5programs;

public class squaremain {

	public static void main(String[] args) {
		square sqr = new square(); //Create instance for square class;
		square sqr2 = new square();
		square sqr3 = new square();
		sqr.side = 20;
		sqr2.side = 30;
		sqr3.side = 50;
        System.out.println("Side of the Square is : "+sqr.side);
        System.out.println("Side of the Square2 is : "+sqr2.side);
        System.out.println("Side of the Square3 is : "+sqr3.side);
        sqr.area = sqr.side * sqr.side;
        sqr2.area = sqr2.side * sqr2.side;
        sqr3.area = sqr3.side * sqr3.side;
        System.out.println("Area of Square is "+sqr.area);
        System.out.println("Area of Square2 is "+sqr2.area);
        System.out.println("Area of Square3 is "+sqr3.area);
        sqr.perimeter=4*sqr.side;
        sqr2.perimeter=4*sqr2.side;
        sqr3.perimeter=4*sqr3.side;
        System.out.println("Perimeter  of Square is "+sqr.perimeter);
        System.out.println("Perimeter  of Square2 is "+sqr2.perimeter);
        System.out.println("Perimeter  of Square3 is "+sqr3.perimeter);
    	}
	}

