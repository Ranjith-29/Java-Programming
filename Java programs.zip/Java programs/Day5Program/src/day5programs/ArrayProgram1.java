package day5programs;

public class ArrayProgram1 {

	public static void main(String[] args) {
			int month_days[] = { 31,28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
			System.out.println("April has " +month_days[3] + " days. ");
	}

}
