package day5programs;

import java.util.Scanner;

public class Printingnum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i,n;
		System.out.println("Enter the value of starting Number" );
		i = sc.nextInt();
		System.out.println("Enter the value of starting Number" );
	    n = sc.nextInt();
		while(i <=n) {
			System.out.println("Enter the Numbers 1 to 100: "+i);
			i++;
		}

	}

}
