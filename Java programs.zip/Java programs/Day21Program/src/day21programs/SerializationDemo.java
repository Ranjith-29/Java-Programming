package day21programs;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class SerializationDemo {

	public static void main(String[] args) throws IOException {
		try {
			//Create Student Class Object
			Student student = new Student(100, "Bala", 99.90f);
			//Create a low Level Stream Pointing to the File
			FileOutputStream fileStream = new FileOutputStream("serializee.txt");
			//Create a High Level Stream
			ObjectOutputStream objectStream = new ObjectOutputStream(fileStream);
			//Perform Serialization
			objectStream.writeObject(student);
			//Close Stream Objects
			System.out.println("Serialization Done");
			fileStream.close();
			objectStream.close();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
