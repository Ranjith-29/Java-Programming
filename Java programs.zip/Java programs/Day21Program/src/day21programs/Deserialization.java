package day21programs;
import java.io.ClassNotFoundException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
public class Deserialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//Create Low Level Stream
			FileInputStream fileStream = new FileInputStream("serializee.txt");
			//Create a High Level Stream
			ObjectInputStream objectStream = new ObjectInputStream(fileStream);
			//perform Deserialization
			Object object = objectStream.readObject();
			objectStream.close();
			fileStream.close();
			Student student = (Student)object;
			student.StudentDetails();
			
		}catch(ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}

	}

}
