package day13programs;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegEx1 {

	public static void main(String[] args) {
		Pattern pat;
		Matcher mat;
		boolean found;
		pat = Pattern.compile("Java is a programming language");
		mat = pat.matcher("Java is a programming language");
		found = mat.matches();
		System.out.println("Testing Java == Java");
        if(found)
        {
        	System.out.println("It Matches");
        }
        else {
        	System.out.println("Doesn't Match");
        }
        //found is used to find whether the both sentence are same or not
        mat = pat.matcher("Java is a programming language, I Love coding in java");
        found = mat.matches();
        if(found) {
        	System.out.println("It Matches");
        }
        else {
        	System.out.println("Doesn't Match");
        }
     }
}

