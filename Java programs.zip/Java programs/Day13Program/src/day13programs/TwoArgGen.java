package day13programs;

public class TwoArgGen<T, V> {
	T tObj;
	V vObj;
    TwoArgGen(T to, V vo) {
    	tObj = to;
    	vObj = vo;
    }
    void showType() {
    	System.out.println("Type of T is: "+tObj.getClass().getName());
    	System.out.println("Type of T is: "+vObj.getClass().getName());        
    }
    T gettObj() {
    	return tObj;
    }
    	
    V getObj() {
    	return vObj;
    }
    
	

}
