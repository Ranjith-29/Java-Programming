package day13programs;

public class StringBuffer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer  stringbuffer = new StringBuffer();
		System.out.println("Length of StringBuffer is: "+stringbuffer.length());
		
		StringBuffer  stringbuffer1 = new StringBuffer("Hello World ");
		System.out.println("Length of StringBuffer is: "+stringbuffer1.length());
		System.out.println("Capacity of StringBuffer is: "+stringbuffer1.capacity()); //capacity default 16 
	}
}
