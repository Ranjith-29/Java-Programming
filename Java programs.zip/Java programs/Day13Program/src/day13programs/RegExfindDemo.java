package day13programs;
//word finding program
import java.util.regex.Pattern;
import java.util.regex.Matcher;


public class RegExfindDemo {

	public static void main(String[] args) {
		Pattern pattern =  Pattern.compile("Java is not fun");
		Matcher matcher1 = pattern.matcher("Java is a powerful programming language. Coding in Java is fun");
		System.out.println("Looking for Java in a sentence");
		if(matcher1.find()) {
			System.out.println("found java as a sub sequence");
		}
		else {
			System.out.println("Couldn't find java");
		}
	/*	while(matcher1.find()) {
			System.out.println("Java found at index: "+matcher1.start());
			System.out.println("Java found and end at index: "+matcher1.end());
		} */

	}

}
