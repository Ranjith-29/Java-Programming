package day13programs;

public class StringBuilderDemo {

	public static void main(String[] args) {
		StringBuilder stringbuilder = new StringBuilder("Code");
		System.out.println("Initial value: "+ stringbuilder);
		
		char[] charSequence = new char[] {'w','i','t','h',' ','B','a','l','a','2','6'};
		stringbuilder.append(charSequence, 0, 11);
		System.out.println("appended value; "+stringbuilder);
		

	}

}
