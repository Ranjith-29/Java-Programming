package day13programs;

public class StringBuffer2 {
//setting length and replacing character program
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer  stringbuffer = new StringBuffer("Hello");
		System.out.println("Length of StringBuffer is: "+stringbuffer);
		System.out.println("Length of StringBuffer is: "+stringbuffer.charAt(1));
		
		stringbuffer.setCharAt(1,'i');
		System.out.println("After Change stringBuffer value: "+stringbuffer);
		System.out.println("After Change charAt(1): "+stringbuffer.charAt(1));
		
		stringbuffer.setLength(3);
		System.out.println("After setLength stringBuffer value: "+stringbuffer);
		System.out.println("After setLength charAt(1): "+stringbuffer.charAt(1));
	}
}
