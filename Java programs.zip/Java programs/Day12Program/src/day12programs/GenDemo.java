package day12programs;

public class GenDemo<T> {
	T obj;
	GenDemo(T obj1){
		obj = obj1;
	}
	T getobj() {
		return obj;
	}
	void showType() {
		System.out.println("Type of T is : "+obj.getClass().getName());
		
	}

}
