package day12programs;

public class ThrowDemoMain {

	public static void main(String[] args) {
		ThrowDemo td = new ThrowDemo(20, 0);
		try {
			ThrowDemo.division();
			
		}catch(ArithmeticException ae) {
			System.out.println("Exception Caught");
		} finally {
			System.out.println("Finally with AE");
		}
		try {
			ThrowDemo.arrayFn();
		}catch(ArrayIndexOutOfBoundsException oob) {
			System.out.println("OOB Caught");
		}finally {
			System.out.println("Finally with OOB");
		}
	}

}
