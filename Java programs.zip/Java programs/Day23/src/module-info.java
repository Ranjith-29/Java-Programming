/**
 * 
 */
/**
 * @author dxcjavafsd29
 *
 */
module Day23 {
	requires java.sql;
}