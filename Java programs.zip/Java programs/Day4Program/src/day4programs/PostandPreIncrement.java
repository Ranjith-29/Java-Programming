package day4programs;

public class PostandPreIncrement {

	public static void main(String[] args) {
		int num1 = 100;
		int y1,y2;
		y1 = num1++;
	    System.out.println("Post increment "+ "y1 value: " +y1+ " num1 : "+num1);
	    int num2 = 100;
	    y2 = ++num2;
	    System.out.println("Pre increment "+ "y2 value: " +y2+ " num2: "+num2); // TODO Auto-generated method stub

	}

}
