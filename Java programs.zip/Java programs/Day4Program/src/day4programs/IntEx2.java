package day4programs;

import java.util.Scanner;

public class IntEx2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        double radius;
        double perimeter;
		System.out.println("Enter the Radius");
		radius = sc.nextDouble();
		perimeter = 2*3.14*radius;
	    System.out.println("Enter Perimeter : "+perimeter); 
	    

	}

}
