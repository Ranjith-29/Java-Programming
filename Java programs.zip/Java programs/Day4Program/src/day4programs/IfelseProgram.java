package day4programs;

import java.util.Scanner;

public class IfelseProgram {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int side1,side2;
		int side3,side4;
		System.out.println("enter the length of a side1");
		side1 = sc.nextInt();
		System.out.println("enter the length of a side2");
		side2 = sc.nextInt();
		if(side1 == side2) System.out.println("Photo Frame is Square Shape");// TODO Auto-generated method stub
		else {
			System.out.println("Photo frame is Rectangle Shape");
	 
		}
		System.out.println("===============================");
		System.out.println("enter the length of a side3");
		side1 = sc.nextInt();
		System.out.println("enter the length of a side4");
		side2 = sc.nextInt();
		if(side1 == side2) System.out.println("Photo Frame is Square Shape");// TODO Auto-generated method stub
		else {
			System.out.println("Photo frame is Rectangle Shape");
		}
	}
}


