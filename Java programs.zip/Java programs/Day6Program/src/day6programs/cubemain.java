package day6programs;

import java.util.Scanner;

public class cubemain {

	public static void main(String[] args) {
		cube cbe = new cube();
		Scanner sc = new Scanner(System.in); 
		System.out.println("Enter the Width of the Box");
		cbe.width = sc.nextDouble();
		System.out.println("Enter the Height of the Box");
		cbe.height = sc.nextDouble();
		System.out.println("Enter the Depth of the Box");
		cbe.depth = sc.nextDouble();
		cbe.volume = cbe.width*cbe.height*cbe.depth;
		System.out.println("The volume of Box with Width: "+cbe.width+ ", Height: "+cbe.height+ ", depth: "+cbe.depth + " is "+cbe.volume+ "\n");
		System.out.println("=====================================\n");
		System.out.println("Enter the Width1 of the Box");
		cbe.width = sc.nextDouble();
		System.out.println("Enter the Height1 of the Box");
		cbe.height = sc.nextDouble();
		System.out.println("Enter the Depth1 of the Box");
		cbe.depth = sc.nextDouble();
		cbe.volume = cbe.width*cbe.height*cbe.depth;
		System.out.println("The volume of Box1 with Width1: "+cbe.width+ ", Height1: "+cbe.height+ ", depth1: "+cbe.depth + " is "+cbe.volume+ "\n");
		System.out.println("=====================================\n");
		System.out.println("Enter the Width2 of the Box");
		cbe.width = sc.nextDouble();
		System.out.println("Enter the Height2 of the Box");
		cbe.height = sc.nextDouble();
		System.out.println("Enter the Depth2 of the Box");
		cbe.depth = sc.nextDouble();
		cbe.volume = cbe.width*cbe.height*cbe.depth;
		System.out.println("The volume of Box2 with Width2: "+cbe.width+ ", Height2: "+cbe.height+ ", depth2: "+cbe.depth + " is "+cbe.volume+ "\n");
		
		
		

	}

}
