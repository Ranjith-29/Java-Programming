package day6programs;

public class cube {
    double width;
	double height;
	double depth;
	double volume;
}
