package day6programs;

public class AutoBoxDemo {

	public static void main(String[] args) {
		long longValue = 747; //Integer iob = 100; Autoboxing
		float floatValue = 99.67f; 
		boolean boolValue = true;
		Long longWrap = longValue;
        Float floatWrap = floatValue; //int i = iob;
        Boolean boolWrap = boolValue;
        System.out.println("longWrap  : "+ longWrap);
        System.out.println("floatWrap : "+ floatWrap);
        System.out.println("boolWrap  : "+ boolWrap);
        long longValue2 = longWrap;
		float floatValue2 = floatWrap;
		boolean boolValue2 = boolWrap;
		System.out.println("longWrap  : "+ longValue2);
        System.out.println("floatWrap : "+ floatValue2);
        System.out.println("boolWrap  : "+ boolValue2);
	}
}
