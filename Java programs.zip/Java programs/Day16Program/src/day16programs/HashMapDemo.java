package day16programs;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		HashMap<String, String> hashMap = new HashMap<String, String>();
		hashMap.put("Bala", "9879654311");
		hashMap.put("Micheal", "9879654331");
		hashMap.put("Sam", "9879474311");
		hashMap.put("Rosy", null);
		hashMap.put("Sunny", "9879654456");
		//get a set of ENtries 
		Set<Map.Entry<String, String>> set = hashMap.entrySet();
		for(Map.Entry<String, String> mapentry : set) {
			System.out.println(mapentry.getKey() + ": ");
			System.out.println(mapentry.getValue() + ": ");
			
		}
		
		
   }
}
