/**
 * 
 */
/**
 * @author dxcjavafsd29
 *
 */
module SBA6 {
	requires java.sql;
}