package day19programs;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Create2 {

	public static void main(String[] args) throws IOException {
		String myTextMsg = "This text is from create2.java";
		FileWriter filewriter = new FileWriter("File2.txt");
		BufferedWriter bufferedWriter = new BufferedWriter(filewriter);
		for(int ctr=0; ctr<myTextMsg.length(); ctr++) {
			bufferedWriter.write(myTextMsg.charAt(ctr));
		}bufferedWriter.close();

	}

}
