package FirstProgram;

public class ThirdProgram {

	public static void main(String[] args) {
		System.out.println("I am Ranjith");
		System.out.println("From Tamilandu");
		System.out.println("Java Training is Interesting");

	}

}
