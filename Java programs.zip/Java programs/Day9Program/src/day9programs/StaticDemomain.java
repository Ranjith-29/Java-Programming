package day9programs;

public class StaticDemomain {

	public static void main(String[] args) {
		 StaticDemo.displayValues(25);

	}
    /* In static we don't need to create obj for class coz its giving op */
}
