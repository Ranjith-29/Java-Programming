package day9programs;

public interface MyInterface {
	void connect();

}
