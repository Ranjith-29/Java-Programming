package day9programs;

public class StaticDemo {
	static int num1 = 10; //global variable
	static int  num2 = 20;
	static void displayValues(int num3) {
		System.out.println("num1: "+num1);
		System.out.println("num2: "+num2);
		System.out.println("num3: "+num3);
	}
	static { // static block - this block execute will execute first after that only everything comes
         System.out.println("Static Block Initialised");
         System.out.println("num1 * num2");
         System.out.println("=================");
	}
}
