package day9programs;

public class IfaceClassMain {

	public static void main(String[] args) {
		IfaceClass ic = new IfaceClass();
		ic.diamondCumulative();
		ic.goldCumulative();

	}

}
