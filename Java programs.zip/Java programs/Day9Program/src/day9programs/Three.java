package day9programs;

public interface Three extends Second {
	void display3();

}
