package day9programs;

public class GeometricFiguremain {

	public static void main(String[] args) {
		/* GeometricFigure geof = new  GeometricFigure(); no need this here coz its abstraction so obj creation no need and
  also in Geometric Figure super class, abstract double area(); inside doesn't have nothing so its we no need to create obj */
		Rectangle rectangle = new Rectangle(12.2,13.3);
		/* Rectangle rectangle = new Rectangle(12.2,13.3); 
		 we can right this way also
		 Rectangle rectangle; // point to null
		 rectangle = new Rectangle(12.2,13.3); 
		 */
        System.out.println(rectangle.area());	
        
        GeometricFigure geof; // point to null
        geof = rectangle;
        System.out.println(geof.area());
        
	}
    
}
