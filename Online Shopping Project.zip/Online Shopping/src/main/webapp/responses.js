function getBotResponse(input) {
    //rock paper scissors
    if (input == "Hi") {
        return "Hello.. How can I help u";
    } else if (input == "I want replace order how i can replace") {
        return "contact our customer care";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "hello") {
        return "Hello there!";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    } else {
        return "Try asking something else!";
    }
}

